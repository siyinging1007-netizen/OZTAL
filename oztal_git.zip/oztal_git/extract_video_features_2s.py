﻿# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import numpy as np
from dotenv import load_dotenv

from src.backends import RealViCLIPBackend

load_dotenv("config.env")


@dataclass
class VideoWindow:
    index: int
    start_seconds: float
    end_seconds: float
    frames: np.ndarray
    start_frame: int | None = None
    end_frame: int | None = None


def env_or_default(name: str, default, cast=str):
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return cast(value)


def env_path(name: str) -> Path | None:
    value = os.environ.get(name)
    if value is None or value == "":
        return None
    return Path(value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract ViCLIP video features with second-based 2s/0.25s windows. No text prompts."
    )
    parser.add_argument("--video", type=Path, required=True, help="Input video path.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory used to save outputs.")
    parser.add_argument("--window-seconds", type=float, default=env_or_default("OZTAL_WINDOW_SECONDS", 2.0, float))
    parser.add_argument("--stride-seconds", type=float, default=env_or_default("OZTAL_STRIDE_SECONDS", 0.25, float))
    parser.add_argument("--num-frames", type=int, default=env_or_default("OZTAL_NUM_FRAMES", 8, int))
    parser.add_argument("--resize", type=int, default=env_or_default("OZTAL_RESIZE", 224, int))
    parser.add_argument("--device", default=env_or_default("OZTAL_DEVICE", "cuda"))
    parser.add_argument("--video-batch-size", type=int, default=env_or_default("OZTAL_VIDEO_BATCH_SIZE", 8, int))
    parser.add_argument("--viclip-repo", type=Path, default=env_path("OZTAL_VICLIP_REPO"))
    parser.add_argument("--checkpoint", type=Path, default=env_path("OZTAL_CHECKPOINT"))
    parser.add_argument("--viclip-adapter", default=os.environ.get("OZTAL_VICLIP_ADAPTER"))
    return parser.parse_args()


def decode_second_windows(video_path: Path, window_seconds: float, stride_seconds: float, num_frames: int, resize: int) -> list[VideoWindow]:
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError("Real video decoding needs opencv-python. Run: pip install opencv-python") from exc

    if window_seconds <= 0:
        raise ValueError("window_seconds must be > 0")
    if stride_seconds <= 0:
        raise ValueError("stride_seconds must be > 0")
    if num_frames <= 0:
        raise ValueError("num_frames must be > 0")

    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    fps = float(capture.get(cv2.CAP_PROP_FPS) or 0.0)
    if fps <= 0:
        capture.release()
        raise RuntimeError(f"Cannot read fps from video: {video_path}")

    decoded_frames: list[np.ndarray] = []
    while True:
        ok, frame_bgr = capture.read()
        if not ok:
            break
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        if resize > 0:
            frame_rgb = cv2.resize(frame_rgb, (resize, resize), interpolation=cv2.INTER_AREA)
        decoded_frames.append(frame_rgb)
    capture.release()

    frame_count = len(decoded_frames)
    if frame_count <= 0:
        raise RuntimeError(f"No frames decoded from video: {video_path}")

    duration_seconds = frame_count / fps
    windows: list[VideoWindow] = []
    frames_array = np.stack(decoded_frames, axis=0)
    start_seconds = 0.0
    index = 0
    epsilon = 1e-9

    while start_seconds + window_seconds <= duration_seconds + epsilon:
        end_seconds = start_seconds + window_seconds
        sample_times = np.linspace(start_seconds, end_seconds, num_frames, endpoint=False)
        frame_indices = np.floor(sample_times * fps).astype(np.int64)
        frame_indices = np.clip(frame_indices, 0, frame_count - 1)
        windows.append(
            VideoWindow(
                index=index,
                start_seconds=float(start_seconds),
                end_seconds=float(end_seconds),
                frames=frames_array[frame_indices],
                start_frame=int(frame_indices[0]),
                end_frame=int(frame_indices[-1]),
            )
        )
        index += 1
        start_seconds += stride_seconds

    if not windows:
        sample_times = np.linspace(0.0, duration_seconds, num_frames, endpoint=False)
        frame_indices = np.floor(sample_times * fps).astype(np.int64)
        frame_indices = np.clip(frame_indices, 0, frame_count - 1)
        windows.append(
            VideoWindow(
                index=0,
                start_seconds=0.0,
                end_seconds=float(duration_seconds),
                frames=frames_array[frame_indices],
                start_frame=int(frame_indices[0]),
                end_frame=int(frame_indices[-1]),
            )
        )
    return windows


def main() -> None:
    started_at = datetime.now().astimezone()
    timer_start = time.perf_counter()
    args = parse_args()

    if args.viclip_repo is None:
        raise SystemExit("--viclip-repo is required")
    if args.checkpoint is None:
        raise SystemExit("--checkpoint is required")

    print("ViCLIP video feature extraction")
    print(f"video: {args.video}")
    print("mode: second_based_windows")
    print(f"window_seconds: {args.window_seconds}")
    print(f"stride_seconds: {args.stride_seconds}")
    print(f"num_frames: {args.num_frames}")

    windows = decode_second_windows(
        video_path=args.video,
        window_seconds=args.window_seconds,
        stride_seconds=args.stride_seconds,
        num_frames=args.num_frames,
        resize=args.resize,
    )
    print(f"windows: {len(windows)}")

    backend = RealViCLIPBackend(
        repo_path=args.viclip_repo,
        checkpoint_path=args.checkpoint,
        device=args.device,
        adapter_module=args.viclip_adapter,
        video_batch_size=args.video_batch_size,
    )
    video_features = backend.encode_video_windows(windows)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    np.save(args.output_dir / "video_features.npy", video_features)

    metadata = {
        "video": str(args.video),
        "backend": "viclip",
        "viclip_repo": str(args.viclip_repo),
        "checkpoint": str(args.checkpoint),
        "checkpoint_name": args.checkpoint.name,
        "feature_extraction_mode": "second_based_windows",
        "window_seconds": args.window_seconds,
        "stride_seconds": args.stride_seconds,
        "num_frames": args.num_frames,
        "resize": args.resize,
        "device": args.device,
        "video_batch_size": args.video_batch_size,
        "extracted_at": started_at.isoformat(timespec="seconds"),
        "elapsed_seconds": round(time.perf_counter() - timer_start, 3),
        "feature_shapes": {"video_features": list(video_features.shape)},
        "windows": [
            {
                "index": window.index,
                "start_seconds": window.start_seconds,
                "end_seconds": window.end_seconds,
                "start_frame": window.start_frame,
                "end_frame": window.end_frame,
            }
            for window in windows
        ],
    }
    (args.output_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"checkpoint: {args.checkpoint}")
    print(f"video_features: {list(video_features.shape)}")
    print(f"elapsed_seconds: {metadata['elapsed_seconds']}")
    print(f"saved to: {args.output_dir}")


if __name__ == "__main__":
    main()

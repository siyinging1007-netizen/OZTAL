from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np

from src.paths import STEP3_DIR, STEP4_DIR, ensure_dir
from src.span_prediction import predict_spans_online


OUTPUT_DIR = ensure_dir(STEP4_DIR)
PREV_DIR = STEP3_DIR
TAU = 10.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run OZ-TAL step 4: Online Action Span Prediction."
    )
    parser.add_argument("--step3-dir", type=Path, default=STEP3_DIR, help="Directory containing BAKC y scores.")
    parser.add_argument("--output-dir", type=Path, default=STEP4_DIR, help="Directory used to save span prediction outputs.")
    parser.add_argument("--tau", type=float, default=TAU, help="Classification threshold.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = ensure_dir(args.output_dir)
    y = np.load(args.step3_dir / "y_scores.npy").astype(np.float32)
    classes = json.loads((args.step3_dir / "classes.json").read_text(encoding="utf-8"))
    step3_metadata = json.loads((args.step3_dir / "metadata.json").read_text(encoding="utf-8"))
    state_matrix, results = predict_spans_online(y, classes, tau=args.tau)
    attach_time_ranges(results, step3_metadata.get("windows"))
    save_outputs(state_matrix, results, output_dir, args.tau)
    print_results(results, classes, y, args.tau)
    plot_timeline(results, y.shape[0], output_dir / "timeline.png")


def attach_time_ranges(results: list[dict], windows: list[dict] | None) -> None:
    if not windows:
        return
    for item in results:
        start_window = windows[item["start"]]
        end_window = windows[item["end"]]
        item["start_seconds"] = float(start_window["start_seconds"])
        item["end_seconds"] = float(end_window["end_seconds"])


def save_outputs(state_matrix: np.ndarray, results: list[dict], output_dir: Path, tau: float) -> None:
    np.save(output_dir / "state_matrix.npy", state_matrix)
    (output_dir / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    metadata = {
        "tau": tau,
        "num_instances": len(results),
        "state_matrix_shape": list(state_matrix.shape),
    }
    (output_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def print_results(results: list[dict], classes: list[str], y: np.ndarray, tau: float) -> None:
    print("OZ-TAL step 4: Online Action Span Prediction")
    if not results:
        print("No action instances detected.")
        flat_index = int(np.argmax(y))
        window_index, class_index = np.unravel_index(flat_index, y.shape)
        print(
            f"max score is {float(y[window_index, class_index]):.4f} "
            f"at window {window_index:03d}, class={classes[class_index]!r}; "
            f"current tau={tau:.4f}"
        )
        print(
            "counts above thresholds: "
            + ", ".join(
                f">{threshold:g}: {int((y > threshold).sum())}"
                for threshold in (10, 5, 2, 1, 0.5, 0)
            )
        )
        return

    durations = []
    counts = Counter()
    for item in results:
        durations.append(item["end"] - item["start"] + 1)
        counts[item["category"]] += 1
        time_range = ""
        if "start_seconds" in item and "end_seconds" in item:
            time_range = f"  [{item['start_seconds']:.2f}s -> {item['end_seconds']:.2f}s]"
        print(
            f"[window {item['start']:03d} -> window {item['end']:03d}]"
            f"{time_range} {item['category']}  confidence: {item['confidence']:.2f}"
        )

    print()
    print(f"Total instances: {len(results)}")
    print(f"Average duration: {float(np.mean(durations)):.2f} frames")
    for class_name in classes:
        print(f"{class_name}: {counts[class_name]}")


def plot_timeline(results: list[dict], num_frames: int, output_path) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib is not installed; skipped timeline.png")
        return

    if not results:
        return

    categories = list(dict.fromkeys(item["category"] for item in results))
    category_to_row = {name: index for index, name in enumerate(categories)}

    fig, ax = plt.subplots(figsize=(14, max(3, len(categories) * 0.6)))
    for item in results:
        row = category_to_row[item["category"]]
        start = item["start"]
        width = item["end"] - item["start"] + 1
        ax.broken_barh([(start, width)], (row - 0.35, 0.7), alpha=0.85)
        ax.text(start, row, item["category"], va="center", ha="left", fontsize=8)

    ax.set_xlim(0, max(num_frames - 1, 1))
    ax.set_yticks(range(len(categories)))
    ax.set_yticklabels(categories)
    ax.set_xlabel("Time-window index")
    ax.set_title("Online action span predictions")
    ax.grid(True, axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    main()

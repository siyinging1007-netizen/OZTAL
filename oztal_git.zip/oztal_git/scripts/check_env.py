from __future__ import annotations

import argparse
import importlib.util
import shutil
import sys
from pathlib import Path


def status(ok: bool, name: str, detail: str) -> None:
    mark = "OK" if ok else "FAIL"
    print(f"[{mark}] {name}: {detail}")


def check_module(name: str) -> bool:
    found = importlib.util.find_spec(name) is not None
    status(found, name, "installed" if found else "not installed")
    return found


def main() -> None:
    parser = argparse.ArgumentParser(description="Check the OZ-TAL ViCLIP local environment.")
    parser.add_argument("--viclip-repo", type=Path, help="Path to local OpenGVLab/InternVideo repo.")
    parser.add_argument("--checkpoint-dir", type=Path, help="Path to downloaded ViCLIP checkpoint/model folder.")
    args = parser.parse_args()

    print(f"Python: {sys.version}")
    status(sys.version_info[:2] == (3, 10), "Python version", "recommended 3.10")

    git = shutil.which("git")
    status(git is not None, "git", git or "not found")

    has_torch = check_module("torch")
    check_module("cv2")
    check_module("numpy")
    check_module("huggingface_hub")

    if has_torch:
        import torch

        status(True, "torch version", torch.__version__)
        cuda_ok = torch.cuda.is_available()
        status(cuda_ok, "torch cuda", "available" if cuda_ok else "not available")
        if cuda_ok:
            status(True, "cuda device", torch.cuda.get_device_name(0))

    if args.viclip_repo:
        status(args.viclip_repo.exists(), "InternVideo repo", str(args.viclip_repo))
        if args.viclip_repo.exists():
            status((args.viclip_repo / "InternVideo2").exists(), "InternVideo2 folder", str(args.viclip_repo / "InternVideo2"))

    if args.checkpoint_dir:
        status(args.checkpoint_dir.exists(), "checkpoint/model folder", str(args.checkpoint_dir))
        if args.checkpoint_dir.exists():
            files = list(args.checkpoint_dir.rglob("*"))
            interesting = [p for p in files if p.suffix.lower() in {".bin", ".pth", ".pt", ".safetensors", ".json", ".py"}]
            status(bool(interesting), "checkpoint files", f"{len(interesting)} candidate files")


if __name__ == "__main__":
    main()

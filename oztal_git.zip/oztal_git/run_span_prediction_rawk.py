from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np

from src.paths import STEP3_DIR, ensure_dir
from src.span_prediction import predict_spans_online


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run span prediction directly on raw class logits k, bypassing BAKC y scores."
    )
    parser.add_argument("--step3-dir", type=Path, default=STEP3_DIR, help="Directory containing step 3 outputs.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory used to save span prediction outputs.")
    parser.add_argument("--tau", type=float, default=7.0, help="Classification threshold applied to raw k logits.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = ensure_dir(args.output_dir)
    k = np.load(args.step3_dir / "k_logits.npy").astype(np.float32)
    classes = json.loads((args.step3_dir / "classes.json").read_text(encoding="utf-8"))
    step3_metadata = json.loads((args.step3_dir / "metadata.json").read_text(encoding="utf-8"))
    state_matrix, results = predict_spans_online(k, classes, tau=args.tau)
    attach_time_ranges(results, step3_metadata.get("windows"))
    save_outputs(state_matrix, results, output_dir, args.tau)
    print_results(results, classes, k, args.tau)


def attach_time_ranges(results: list[dict], windows: list[dict] | None) -> None:
    if not windows:
        return
    for item in results:
        start_window = windows[item["start"]]
        end_window = windows[item["end"]]
        item["start_seconds"] = float(start_window["start_seconds"])
        item["end_seconds"] = float(end_window["end_seconds"])


def save_outputs(state_matrix: np.ndarray, results: list[dict], output_dir: Path, tau: float) -> None:
    np.save(output_dir / "state_matrix.npy", state_matrix)
    (output_dir / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    metadata = {
        "tau": tau,
        "score_source": "k_logits",
        "num_instances": len(results),
        "state_matrix_shape": list(state_matrix.shape),
    }
    (output_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def print_results(results: list[dict], classes: list[str], k: np.ndarray, tau: float) -> None:
    print("Step 4 raw-k span prediction")
    if not results:
        print("No action instances detected.")
        flat_index = int(np.argmax(k))
        window_index, class_index = np.unravel_index(flat_index, k.shape)
        print(
            f"max score is {float(k[window_index, class_index]):.4f} "
            f"at window {window_index:03d}, class={classes[class_index]!r}; "
            f"current tau={tau:.4f}"
        )
        print(
            "counts above thresholds: "
            + ", ".join(
                f">{threshold:g}: {int((k > threshold).sum())}"
                for threshold in (10, 5, 2, 1, 0.5, 0)
            )
        )
        return

    durations = []
    counts = Counter()
    for item in results:
        durations.append(item["end"] - item["start"] + 1)
        counts[item["category"]] += 1
        time_range = ""
        if "start_seconds" in item and "end_seconds" in item:
            time_range = f"  [{item['start_seconds']:.2f}s -> {item['end_seconds']:.2f}s]"
        print(
            f"[window {item['start']:03d} -> window {item['end']:03d}]"
            f"{time_range} {item['category']}  confidence: {item['confidence']:.2f}"
        )

    print()
    print(f"Total instances: {len(results)}")
    print(f"Average duration: {float(np.mean(durations)):.2f} frames")
    for class_name in classes:
        print(f"{class_name}: {counts[class_name]}")


if __name__ == "__main__":
    main()

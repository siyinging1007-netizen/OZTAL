﻿# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


DEFAULT_VIDEO_DIR = Path(r"D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_test_set_mp4")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Batch extract ViCLIP video features with second-based windows. No text prompts."
    )
    parser.add_argument("--video-dir", type=Path, default=DEFAULT_VIDEO_DIR, help="Directory containing input .mp4 videos.")
    parser.add_argument("--video-list", type=Path, help="Optional text file with one video filename or path per line.")
    parser.add_argument("--output-root", type=Path, default=Path("output/video_features_2s"), help="Feature output root.")
    parser.add_argument("--device", default="cuda", help="Device for ViCLIP, such as cuda or cpu.")
    parser.add_argument("--python", default=sys.executable, help="Python executable used to run extract_video_features_2s.py.")
    parser.add_argument("--window-seconds", type=float, default=2.0, help="Temporal window length in seconds.")
    parser.add_argument("--stride-seconds", type=float, default=0.25, help="Temporal stride in seconds.")
    parser.add_argument("--num-frames", type=int, default=8, help="Frames sampled per temporal window.")
    parser.add_argument("--resize", type=int, help="Decoded frame size.")
    parser.add_argument("--video-batch-size", type=int, help="Video windows encoded per GPU batch.")
    parser.add_argument("--viclip-repo", type=Path, help="Local InternVideo repository path.")
    parser.add_argument("--checkpoint", type=Path, help="Local ViCLIP checkpoint path.")
    parser.add_argument("--viclip-adapter", help="Optional ViCLIP adapter module.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parent
    videos = collect_videos(args, project_root)
    failed: list[str] = []
    total = len(videos)

    if total == 0:
        raise SystemExit("No videos found.")

    for index, video_path in enumerate(videos, start=1):
        video_stem = video_path.stem
        output_dir = args.output_root / video_stem / "step1_feature_extraction"
        feature_path = output_dir / "video_features.npy"

        if feature_path.exists():
            print(f"[{index}/{total}] {video_stem} skipped")
            continue

        command = build_command(args, video_path, output_dir)
        try:
            subprocess.run(command, cwd=project_root, check=True)
        except subprocess.CalledProcessError as exc:
            failed.append(video_stem)
            print(f"WARNING: [{index}/{total}] {video_stem} failed with exit code {exc.returncode}; continue")
            continue

        print(f"[{index}/{total}] {video_stem} done")

    print()
    print(f"Feature extraction finished. Total: {total}, failed: {len(failed)}")
    if failed:
        print("Failed videos:")
        for video_stem in failed:
            print(f"  {video_stem}")


def collect_videos(args: argparse.Namespace, project_root: Path) -> list[Path]:
    if args.video_list:
        video_list = resolve_path(args.video_list, project_root)
        names = [
            line.strip().lstrip("\ufeff")
            for line in video_list.read_text(encoding="utf-8-sig").splitlines()
            if line.strip()
        ]
        videos = []
        for name in names:
            path = Path(name)
            if path.suffix == "":
                path = path.with_suffix(".mp4")
            videos.append(path if path.is_absolute() else args.video_dir / path)
        return videos
    return sorted(args.video_dir.glob("*.mp4"))


def resolve_path(path: Path, project_root: Path) -> Path:
    return path if path.is_absolute() else project_root / path


def build_command(args: argparse.Namespace, video_path: Path, output_dir: Path) -> list[str]:
    command = [
        args.python,
        "extract_video_features_2s.py",
        "--video",
        str(video_path),
        "--output-dir",
        str(output_dir),
        "--device",
        args.device,
        "--window-seconds",
        str(args.window_seconds),
        "--stride-seconds",
        str(args.stride_seconds),
        "--num-frames",
        str(args.num_frames),
    ]
    append_optional(command, "--resize", args.resize)
    append_optional(command, "--video-batch-size", args.video_batch_size)
    append_optional(command, "--viclip-repo", args.viclip_repo)
    append_optional(command, "--checkpoint", args.checkpoint)
    append_optional(command, "--viclip-adapter", args.viclip_adapter)
    return command


def append_optional(command: list[str], flag: str, value: object | None) -> None:
    if value is not None:
        command.extend([flag, str(value)])


if __name__ == "__main__":
    main()

# 给底层特征提取模型统一接口
from __future__ import annotations

import hashlib
import importlib
import inspect
import io
import logging
import os
import shutil
import contextlib
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, Sequence

import numpy as np


def l2_normalize(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    norm = np.linalg.norm(x, axis=1, keepdims=True)
    return x / np.maximum(norm, eps)


@dataclass
class FeatureBatch:
    video_features: np.ndarray
    text_features: np.ndarray
    prompts: list[str]
    prompt_classes: list[str]


class ViCLIPBackend(Protocol):
    def encode_video_windows(self, windows: int | Sequence[Any]) -> np.ndarray:
        ...

    def encode_text_prompts(self, prompts: list[str]) -> np.ndarray:
        ...


class RealViCLIPBackend:
    """OpenGVLab/InternVideo ViCLIP adapter.

    The official InternVideo repository has changed layout across releases, so
    this adapter tries common entry points first and then gives a precise error.
    """

    def __init__(
        self,
        repo_path: str | Path,
        checkpoint_path: str | Path | None = None,
        device: str = "cuda",
        adapter_module: str | None = None,
        video_batch_size: int = 1,
    ) -> None:
        self.repo_path = Path(repo_path).resolve()
        self.checkpoint_path = Path(checkpoint_path).resolve() if checkpoint_path else None
        self.device = device
        self.adapter_module = adapter_module
        self.video_batch_size = max(1, int(video_batch_size))
        self.torch = self._import_torch()
        self.model, self.module = self._load_model()

    def encode_video_windows(self, windows: Sequence[Any]) -> np.ndarray:
        feature_chunks: list[np.ndarray] = []
        for start in range(0, len(windows), self.video_batch_size):
            chunk = windows[start:start + self.video_batch_size]
            frames = np.stack([window.frames for window in chunk], axis=0)
            video_tensor = self._frames_to_tensor(frames)
            with self.torch.no_grad():
                features = self._call_video_encoder(video_tensor)
            feature_chunks.append(self._to_numpy(features))
            del video_tensor
            if self.device.startswith("cuda") and hasattr(self.torch.cuda, "empty_cache"):
                self.torch.cuda.empty_cache()
        return l2_normalize(np.concatenate(feature_chunks, axis=0))

    def encode_text_prompts(self, prompts: list[str]) -> np.ndarray:
        with self.torch.no_grad():
            features = self._call_text_encoder(prompts)
        return l2_normalize(self._to_numpy(features))

    def _load_model(self) -> tuple[Any, Any]:
        if self.checkpoint_path and self.checkpoint_path.suffix.lower() == ".pth":
            return self._load_legacy_viclip_pth()
        if self.checkpoint_path and (self.checkpoint_path / "config.json").exists():
            return self._load_hf_model()
        if not self.repo_path.exists():
            raise RuntimeError(f"ViCLIP repo path does not exist: {self.repo_path}")
        sys.path.insert(0, str(self.repo_path))
        self._patch_pkg_resources_packaging()

        module_names = [self.adapter_module] if self.adapter_module else [
            "viclip",
            "Data.InternVid.viclip.viclip",
            "InternVideo1.Pretrain.ViCLIP.viclip",
        ]

        errors = []
        for module_name in [name for name in module_names if name]:
            try:
                module = importlib.import_module(module_name)
                model = self._build_model_from_module(module)
                model.eval()
                if hasattr(model, "to"):
                    model = model.to(self.device)
                return model, module
            except Exception as exc:
                errors.append(f"{module_name}: {exc}")

        joined = "\n".join(errors)
        raise RuntimeError(
            "Could not load ViCLIP from the given InternVideo repo.\n"
            "Use --viclip-adapter to point to a module that exposes get_viclip, "
            "load_model, or build_model.\n"
            f"Tried:\n{joined}"
        )

    def _load_hf_model(self) -> tuple[Any, Any]:
        sys.path.insert(0, str(self.checkpoint_path))
        cache_dir = Path.cwd() / "work" / "hf_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        os.environ.setdefault("HF_HOME", str(cache_dir))
        os.environ.setdefault("HF_MODULES_CACHE", str(cache_dir / "modules"))
        try:
            transformers = importlib.import_module("transformers")
            previous_level = logging.getLogger("transformers").level
            logging.getLogger("transformers").setLevel(logging.ERROR)
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                config = transformers.AutoConfig.from_pretrained(
                    str(self.checkpoint_path),
                    trust_remote_code=True,
                )
            self._disable_optional_cuda_kernels(config)
            self._sync_hf_remote_code_cache(cache_dir)
            if hasattr(config, "device"):
                config.device = self.device
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                model = transformers.AutoModel.from_pretrained(
                    str(self.checkpoint_path),
                    config=config,
                    trust_remote_code=True,
                )
            logging.getLogger("transformers").setLevel(previous_level)
            model.eval()
            if hasattr(model, "to"):
                model = model.to(self.device)
            return model, model
        except Exception as exc:
            raise RuntimeError(f"Could not load Hugging Face ViCLIP checkpoint: {self.checkpoint_path}: {exc}") from exc

    def _load_legacy_viclip_pth(self) -> tuple[Any, Any]:
        if self.checkpoint_path is None:
            raise RuntimeError("checkpoint_path is required for legacy ViCLIP .pth loading.")
        if not self.checkpoint_path.exists():
            raise RuntimeError(f"ViCLIP checkpoint does not exist: {self.checkpoint_path}")
        if not self.repo_path.exists():
            raise RuntimeError(f"ViCLIP repo path does not exist: {self.repo_path}")

        sys.path.insert(0, str(self.repo_path))
        self._patch_pkg_resources_packaging()
        module = importlib.import_module("Data.InternVid.viclip.viclip")
        model_class = getattr(module, "ViCLIP")

        # Build the legacy ViCLIP architecture first, then load the requested
        # checkpoint here so we can print strict=False diagnostics.
        model = model_class(pretrain=None)
        checkpoint = self.torch.load(
            str(self.checkpoint_path),
            map_location="cpu",
            weights_only=False,
        )
        state_dict = checkpoint.get("model", checkpoint)
        missing_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)
        print("缺失参数数量:", len(missing_keys))
        print("多余参数数量:", len(unexpected_keys))
        print("缺失参数前5个:", missing_keys[:5])
        print("多余参数前5个:", unexpected_keys[:5])

        model.eval()
        if hasattr(model, "to"):
            model = model.to(self.device)
        return model, module

    def _build_model_from_module(self, module: Any) -> Any:
        for factory_name in ("get_viclip", "load_model", "build_model"):
            factory = getattr(module, factory_name, None)
            if factory is None:
                continue
            kwargs = self._factory_kwargs(factory)
            return factory(**kwargs)

        model_class = getattr(module, "ViCLIP", None)
        if model_class is not None:
            kwargs = self._factory_kwargs(model_class)
            return model_class(**kwargs)

        model = getattr(module, "model", None)
        if model is not None:
            return model
        raise RuntimeError("No get_viclip/load_model/build_model/model entry point found.")

    def _factory_kwargs(self, factory: Any) -> dict[str, Any]:
        parameters = inspect.signature(factory).parameters
        kwargs: dict[str, Any] = {}
        if "device" in parameters:
            kwargs["device"] = self.device
        if self.checkpoint_path:
            for name in ("checkpoint_path", "checkpoint", "ckpt_path", "pretrained", "pretrained_path", "pretrain"):
                if name in parameters:
                    kwargs[name] = str(self.checkpoint_path)
                    break
        return kwargs

    def _frames_to_tensor(self, frames: np.ndarray) -> Any:
        tensor = self.torch.from_numpy(frames)
        tensor = tensor.permute(0, 1, 4, 2, 3)
        if hasattr(self.model, "transform"):
            # HF InternVideo2 demo passes uint8 [T, C, H, W] to model.transform;
            # the transform itself converts to float and divides by 255.
            batches = [self.model.transform(item) for item in tensor]
            tensor = self.torch.stack(batches, dim=0)
        else:
            tensor = tensor.float() / 255.0
            mean = self.torch.tensor([0.485, 0.456, 0.406]).view(1, 1, 3, 1, 1)
            std = self.torch.tensor([0.229, 0.224, 0.225]).view(1, 1, 3, 1, 1)
            tensor = (tensor - mean) / std
        return tensor.to(self.device)

    def _call_video_encoder(self, video_tensor: Any) -> Any:
        for owner in (self.model, self.module):
            for name in ("encode_video", "get_video_features", "get_vid_feat"):
                fn = getattr(owner, name, None)
                if fn is not None:
                    return fn(video_tensor)
            encode_vision = getattr(owner, "encode_vision", None)
            if encode_vision is not None:
                return self._try_call_encode_vision(encode_vision, video_tensor)
        if callable(self.model):
            return self.model(video_tensor)
        raise RuntimeError("Loaded ViCLIP model has no known video encoding method.")

    def _try_call_encode_vision(self, fn: Any, video_tensor: Any) -> Any:
        try:
            parameters = inspect.signature(fn).parameters
            if "test" in parameters:
                return fn(video_tensor, test=True)
        except (TypeError, ValueError):
            pass
        return fn(video_tensor)

    def _call_text_encoder(self, prompts: list[str]) -> Any:
        for owner in (self.model, self.module):
            encode_text = getattr(owner, "encode_text", None)
            tokenizer = getattr(owner, "tokenizer", None)
            if encode_text is not None and tokenizer is not None and callable(tokenizer):
                return self._call_tokenized_text_encoder(encode_text, tokenizer, prompts)
            for name in ("encode_text", "get_text_feat", "get_text_features", "text_encoder"):
                fn = getattr(owner, name, None)
                if fn is not None:
                    result = self._try_call_text_fn(fn, prompts)
                    if result is not None:
                        return result
        raise RuntimeError("Loaded ViCLIP model has no known text encoding method.")

    def _call_tokenized_text_encoder(self, encode_text: Any, tokenizer: Any, prompts: list[str]) -> Any:
        # Match the official InternVideo2 demo: model.tokenizer(texts) -> model.encode_text(text_input).
        text_input: Any = tokenizer(prompts)
        if hasattr(text_input, "to"):
            text_input = text_input.to(self.device)
        elif isinstance(text_input, dict):
            text_input = {
                key: value.to(self.device) if hasattr(value, "to") else value
                for key, value in text_input.items()
            }
        return encode_text(text_input)

    def _try_call_text_fn(self, fn: Any, prompts: list[str]) -> Any:
        try:
            return fn(prompts)
        except TypeError:
            pass

        tokenizer = self._find_tokenizer()
        if tokenizer is None:
            raise

        text_input: Any = tokenizer(prompts)
        if hasattr(text_input, "to"):
            text_input = text_input.to(self.device)
        elif isinstance(text_input, dict):
            text_input = {
                key: value.to(self.device) if hasattr(value, "to") else value
                for key, value in text_input.items()
            }

        if isinstance(text_input, dict):
            return fn(**text_input)
        return fn(text_input)

    def _find_tokenizer(self) -> Any:
        for owner in (self.module, self.model):
            for name in ("tokenize", "tokenizer", "build_tokenizer"):
                tokenizer = getattr(owner, name, None)
                if tokenizer is None:
                    continue
                if name == "build_tokenizer":
                    return tokenizer()
                return tokenizer
        return None

    def _to_numpy(self, value: Any) -> np.ndarray:
        if isinstance(value, (tuple, list)):
            value = value[0]
        if hasattr(value, "detach"):
            value = value.detach()
        if hasattr(value, "float"):
            value = value.float()
        if hasattr(value, "cpu"):
            value = value.cpu()
        if hasattr(value, "numpy"):
            return value.numpy().astype(np.float32)
        return np.asarray(value, dtype=np.float32)

    @staticmethod
    def _import_torch() -> Any:
        try:
            return importlib.import_module("torch")
        except ImportError as exc:
            raise RuntimeError("Real ViCLIP backend needs PyTorch. Install torch first.") from exc

    @staticmethod
    def _patch_pkg_resources_packaging() -> None:
        try:
            import packaging
            import pkg_resources
        except ImportError:
            return
        if not hasattr(pkg_resources, "packaging"):
            pkg_resources.packaging = packaging

    @staticmethod
    def _disable_optional_cuda_kernels(config: Any) -> None:
        vision_encoder = getattr(getattr(config, "model", None), "vision_encoder", None)
        if vision_encoder is None:
            return
        for name in ("use_flash_attn", "use_fused_rmsnorm", "use_fused_mlp"):
            try:
                setattr(vision_encoder, name, False)
            except Exception:
                pass

    def _sync_hf_remote_code_cache(self, cache_dir: Path) -> None:
        """Transformers may miss nested relative imports from local remote-code repos."""
        if self.checkpoint_path is None:
            return
        modules_root = cache_dir / "modules" / "transformers_modules" / self.checkpoint_path.name
        if not modules_root.exists():
            return
        for target_dir in [path for path in modules_root.rglob("*") if path.is_dir()] + [modules_root]:
            for source in self.checkpoint_path.glob("*.py"):
                destination = target_dir / source.name
                if not destination.exists():
                    shutil.copy2(source, destination)


def compute_viclip_batch(
    video_windows: int | Sequence[Any],
    classes: list[str],
    backend: ViCLIPBackend,
    prompt_bank: dict[str, list[str]] | None = None,
) -> FeatureBatch:
    if prompt_bank is None:
        raise ValueError("prompt_bank is required. This project uses DeepSeek prompts only.")

    prompts = []
    prompt_classes = []
    for action in classes:
        for prompt in prompt_bank.get(action, []):
            prompts.append(prompt)
            prompt_classes.append(action)

    video_features = backend.encode_video_windows(video_windows)
    text_features = backend.encode_text_prompts(prompts)
    return FeatureBatch(
        video_features=video_features,
        text_features=text_features,
        prompts=prompts,
        prompt_classes=prompt_classes,
    )


def select_single_prompt_features(
    text_features: np.ndarray,
    prompt_classes: list[str],
    classes: list[str],
) -> np.ndarray:
    """Map one prompt embedding to each action class without averaging."""
    class_features = []
    for action in classes:
        indices = [index for index, prompt_class in enumerate(prompt_classes) if prompt_class == action]
        if len(indices) != 1:
            raise ValueError(
                f"Expected exactly one prompt for class {action!r}, got {len(indices)}."
            )
        class_features.append(text_features[indices[0]].astype(np.float32))
    return np.stack(class_features, axis=0)

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class VideoWindow:
    index: int
    start_seconds: float
    end_seconds: float
    frames: np.ndarray
    start_frame: int | None = None
    end_frame: int | None = None


def decode_video_windows(
    video_path: str | Path,
    num_frames: int,
    resize: int = 224,
) -> list[VideoWindow]:
    """Decode consecutive original-FPS windows with frame-by-frame stride."""
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError("Real video decoding needs opencv-python. Run: pip install opencv-python") from exc

    if num_frames <= 0:
        raise ValueError("num_frames must be > 0")

    path = str(video_path)
    print(path)
    capture = cv2.VideoCapture(path)
    if not capture.isOpened():
        raise RuntimeError(f"Cannot open video: {path}")

    fps = float(capture.get(cv2.CAP_PROP_FPS) or 0.0)
    if fps <= 0:
        capture.release()
        raise RuntimeError(f"Cannot read fps from video: {path}")

    decoded_frames: list[np.ndarray] = []
    while True:
        ok, frame_bgr = capture.read()
        if not ok:
            break
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        if resize > 0:
            frame_rgb = cv2.resize(frame_rgb, (resize, resize), interpolation=cv2.INTER_AREA)
        decoded_frames.append(frame_rgb)
    capture.release()

    frame_count = len(decoded_frames)
    if frame_count <= 0:
        raise RuntimeError(f"No frames decoded from video: {path}")
    if frame_count < num_frames:
        raise RuntimeError(
            f"Video has {frame_count} frames, fewer than num_frames={num_frames}: {path}"
        )

    frames_array = np.stack(decoded_frames, axis=0)
    windows: list[VideoWindow] = []
    #逐1帧滑动
    for window_index, start_frame in enumerate(range(0, frame_count - num_frames + 1)):
        end_frame = start_frame + num_frames - 1
        windows.append(
            VideoWindow(
                index=window_index,
                start_seconds=float(start_frame / fps),
                end_seconds=float((end_frame + 1) / fps),
                frames=frames_array[start_frame:end_frame + 1],
                start_frame=start_frame,
                end_frame=end_frame,
            )
        )
    return windows

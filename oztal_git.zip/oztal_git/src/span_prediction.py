from __future__ import annotations

from math import sqrt

import numpy as np


def predict_spans_online(
    y: np.ndarray,
    classes: list[str],
    tau: float = 10.0,
) -> tuple[np.ndarray, list[dict]]:

    if y.ndim != 2:
        raise ValueError("y must have shape [T, K].")

    num_frames, num_classes = y.shape
    state_matrix = np.zeros((num_frames, num_classes), dtype=np.int64)
    active_starts: list[int | None] = [None] * num_classes
    results: list[dict] = []

    for frame_index in range(num_frames):
        # 把每个类别连续超过阈值tau的窗口 合并成动作片段
        state_matrix[frame_index] = (y[frame_index] > tau).astype(np.int64)
        previous_state = state_matrix[frame_index - 1] if frame_index > 0 else np.zeros(num_classes, dtype=np.int64)
        current_state = state_matrix[frame_index]

        for class_index in range(num_classes):
            if previous_state[class_index] == 0 and current_state[class_index] == 1:
                active_starts[class_index] = frame_index
            elif previous_state[class_index] == 1 and current_state[class_index] == 0:
                start = active_starts[class_index]
                if start is not None:
                    results.append(make_instance(y, classes, class_index, start, frame_index - 1))
                    active_starts[class_index] = None

    last_frame = num_frames - 1
    for class_index, start in enumerate(active_starts):
        if start is not None:
            results.append(make_instance(y, classes, class_index, start, last_frame))

    results.sort(key=lambda item: (item["start"], item["end"], item["category"]))
    return state_matrix, results


def make_instance(
    y: np.ndarray,
    classes: list[str],
    class_index: int,
    start: int,
    end: int,
) -> dict:
    # 置信度=该片段内所有窗口分数之和 / sqrt(片段窗口数量)
    duration = end - start + 1
    confidence = float(y[start:end + 1, class_index].sum() / sqrt(duration))
    return {
        "start": int(start),
        "end": int(end),
        "category": classes[class_index],
        "confidence": confidence,
    }

from __future__ import annotations

from collections import deque
from typing import Deque

import torch
import torch.nn as nn
import torch.nn.functional as F


class MGFEModule(nn.Module):
    """Memory-Guided Feature Enhancement from OZ-TAL step 2.

    The module processes frames sequentially and keeps a FIFO memory queue of
    foreground features only. No future frame information is used.
    """

    def __init__(self, L_q: int = 20, theta: float = 0.8) -> None:
        super().__init__()
        if L_q <= 0:
            raise ValueError("L_q must be positive.")
        self.L_q = int(L_q)
        self.theta = float(theta)
        self.reset_state()

    def reset_state(self) -> None:
        """Clear the memory queue before processing a new video."""
        self.memory_queue: Deque[torch.Tensor] = deque(maxlen=self.L_q)

    def forward(
        self,
        video_features: torch.Tensor,
        foreground_feature: torch.Tensor,
        background_feature: torch.Tensor,
    ) -> torch.Tensor:
        """Enhance video features frame by frame.

        Args:
            video_features: Tensor of shape [T, D]
            foreground_feature: Tensor of shape [D]
            background_feature: Tensor of shape [D]

        Returns:
            Tensor of shape [T, D] with enhanced features z_t.
        """
        if video_features.ndim != 2:
            raise ValueError("video_features must have shape [T, D].")
        if foreground_feature.ndim != 1 or background_feature.ndim != 1:
            raise ValueError("foreground_feature and background_feature must have shape [D].")
        if video_features.shape[1] != foreground_feature.shape[0]:
            raise ValueError("Feature dimension mismatch between video_features and foreground_feature.")
        if foreground_feature.shape != background_feature.shape:
            raise ValueError("foreground_feature and background_feature must have the same shape.")

        outputs = []
        with torch.no_grad():
            for frame_feature in video_features:
                outputs.append(self.process_step(frame_feature, foreground_feature, background_feature))
        return torch.stack(outputs, dim=0)

    def process_step(
        self,
        x_t: torch.Tensor,
        f_a: torch.Tensor,
        f_b: torch.Tensor,
    ) -> torch.Tensor:
        """Process one frame in online order."""
        if x_t.ndim != 1:
            raise ValueError("x_t must have shape [D].")

        x_t = x_t.detach()
        f_a = f_a.detach()
        f_b = f_b.detach()

        #计算当前帧和前景背景的相似度
        foreground_score = F.cosine_similarity(x_t.unsqueeze(0), f_a.unsqueeze(0), dim=-1).squeeze(0)
        background_score = F.cosine_similarity(x_t.unsqueeze(0), f_b.unsqueeze(0), dim=-1).squeeze(0)
        #如果前景大于背景 当前帧存入记忆库
        if background_score < foreground_score:
            self.memory_queue.append(x_t.clone())

        if not self.memory_queue:
            return x_t

        memory_bank = torch.stack(list(self.memory_queue), dim=0)

       #先计算记忆库的普通平均特征。和当前帧比较，若小于阈值，则当前帧不融合，返回xt
        q_bar = memory_bank.mean(dim=0)
        current_similarity = F.cosine_similarity(x_t.unsqueeze(0), q_bar.unsqueeze(0), dim=-1).squeeze(0)
        if current_similarity.item() < self.theta:
            return x_t

       #时间加权平均得出记忆库的平均特征： 先计算权重 越新的记忆帧权重越大
        queue_size = memory_bank.shape[0]
        weights = torch.tensor(
            [1.0 / (self.L_q + 1 - i) for i in range(1, queue_size + 1)],
            dtype=memory_bank.dtype,
            device=memory_bank.device,
        )
        #公式3 计算加权平均特征 除以记忆库容量
        q_tilde = (memory_bank * weights.unsqueeze(1)).sum(dim=0) / queue_size

        # lambda_t = 0.5 * norm(cos(x_t, q_bar)).
        # 相似度归一化
        # Cosine similarity lies in [-1, 1], so norm(.) maps it to [0, 1].
        normalized_similarity = self._normalize_similarity(F.cosine_similarity(x_t.unsqueeze(0), q_bar.unsqueeze(0), dim=-1).squeeze(0))
        lambda_t = 0.5 * normalized_similarity

        # 特征融合 当前xt占主导，历史前景记忆库q_tilde只作为补充，lambda_t小于0.5
        z_t = (1.0 - lambda_t) * x_t + lambda_t * q_tilde
        return z_t

    @staticmethod
    def _normalize_similarity(similarity: torch.Tensor) -> torch.Tensor:
        return ((similarity + 1.0) / 2.0).clamp(0.0, 1.0)

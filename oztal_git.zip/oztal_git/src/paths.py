from __future__ import annotations

import os
from pathlib import Path


EXP_ROOT = Path("output") / "exp001"
STEP1_DIR = EXP_ROOT / "step1_feature_extraction"
STEP2_DIR = EXP_ROOT / "step2_mgfe"
STEP3_DIR = EXP_ROOT / "step3_bakc"
STEP4_DIR = EXP_ROOT / "step4_span_prediction"


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    os.makedirs(path, exist_ok=True)
    return path

from __future__ import annotations
from dotenv import load_dotenv
load_dotenv("config.env", override=True, encoding="utf-8-sig")
import json
import os
import urllib.error
import urllib.request


class DeepSeekPromptGenerator:

    def __init__(
        self,
        api_key:str | None = None,
        model: str = "deepseek-v4-pro",
        base_url: str = "https://api.deepseek.com",
        timeout_seconds: int = 60,
    ) -> None:
        self.api_key = api_key or os.environ.get("DEEPSEEK_API_KEY")
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds

    def generate(self, classes: list[str]) -> dict[str, list[str]]:
        if not self.api_key:
            raise RuntimeError("DEEPSEEK_API_KEY is not set.")

        payload = {
            "model": self.model,
            "messages": [
                {
                    #全局指令 区分动作、避免副词和生僻词
                    "role": "system",
                    "content": (
                        "Given an action, please write a short description summarizing "
                        "the key components of the action, following these two requirements: "
                        "1. The description should differentiate the action from other actions. "
                        "2. Avoid using adverbs and obscure words. "
                        "Output the answer in this JSON format: {\"<action>\": \"<description>\"}"
                    ),
                },
                {
                    #当前输入的动作类别
                    "role": "user",
                    "content": f"Actions: {classes}"
                },
            ],
            "stream": False,
            "temperature": 0.2,
        }
        response = self._post_json("/chat/completions", payload)
        content = response["choices"][0]["message"]["content"]
        return self._parse_prompt_json(content, classes)

    def _post_json(self, path: str, payload: dict) -> dict:
        body = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=body,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"DeepSeek API HTTP {exc.code}: {detail}") from exc

    @staticmethod
    def _parse_prompt_json(content: str, classes: list[str]) -> dict[str, list[str]]:
        cleaned = content.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            cleaned = cleaned.removeprefix("json").strip()
        data = json.loads(cleaned)
        return {
            action: [data[action]]
            for action in classes
            if action in data
        }


def build_prompt_bank(
    classes: list[str],
    prompt_mode: str = "deepseek_sentence",
    deepseek_model: str = "deepseek-v4-pro",
    num_steps: int = 3,
) -> dict[str, list[str]]:
    if prompt_mode not in ("deepseek_sentence", "deepseek"):
        raise RuntimeError(f"Unsupported prompt_mode for original DeepSeek prompts: {prompt_mode}")
    return DeepSeekPromptGenerator(model=deepseek_model).generate(classes)

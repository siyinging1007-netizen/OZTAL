from __future__ import annotations

import torch
import torch.nn.functional as F


EPS = 1e-6


def compute_bakc(
    enhanced_features: torch.Tensor,
    class_text_features: torch.Tensor,
    background_feature: torch.Tensor,
    scale: float = 100.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    #归一化特征
    z_norm = F.normalize(enhanced_features, dim=1)
    cls_norm = F.normalize(class_text_features, dim=1)
    bg_norm = F.normalize(background_feature, dim=0)

    # @点积计算余弦相似度。每个时间窗口的增强特征和每个类别文本特征做相似度计算
    k = scale * (z_norm @ cls_norm.T) #[T,D]@[D,K]=[T,K],第 t 个窗口和第 k 个动作类别文本的相似度分数
    r = scale * (z_norm @ bg_norm)#r[t] = 第 t 个窗口和背景文本的相似度分数

    # 计算背景惩罚权重alapha，每个窗口/每个类别都有惩罚权重
    denominator = k + r.unsqueeze(1)
    #防止denominator = k + r.unsqueeze(1)为0，则用1e-6代替
    denominator_safe = torch.where(
        denominator.abs() < EPS,
        torch.sign(denominator) * EPS + (denominator == 0).to(denominator.dtype) * EPS,
        denominator,
    )
    #alpha = 动作分数 / (动作分数 + 背景分数)，限制aphla范围最小为0.5，最大为1
    alpha_raw = k / denominator_safe
    alpha = torch.clamp(alpha_raw, min=0.5, max=1.0)

    # 最终分数 = alpha * 动作分数 - (1-alpha) * 背景分数
    #y: [T, K]：T = 时间窗口数量。K = 动作类别数量。
    #y[t, k] = 第 t 个窗口属于第 k 个动作类别的最终 BAKC 分数
    lambda_bg = 0.5
    y = alpha * k - lambda_bg*(1.0 - alpha) * r.unsqueeze(1)
    return k, r, alpha, y

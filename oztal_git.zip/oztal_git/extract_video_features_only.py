# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
import os
import time
from datetime import datetime
from pathlib import Path

import numpy as np
from dotenv import load_dotenv

from src.backends import RealViCLIPBackend
from src.video_windows import decode_video_windows

load_dotenv("config.env")


def env_or_default(name: str, default, cast=str):
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return cast(value)


def env_path(name: str) -> Path | None:
    value = os.environ.get(name)
    if value is None or value == "":
        return None
    return Path(value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract only ViCLIP video features with original-frame sliding windows. No text prompts or DeepSeek calls."
    )
    parser.add_argument("--video", type=Path, required=True, help="Input video path.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory used to save outputs.")
    parser.add_argument(
        "--window-frames",
        type=int,
        default=env_or_default("OZTAL_WINDOW_FRAMES", 8, int),
        help="Consecutive original video frames per ViCLIP window. OZ-TAL Ls=8 by default.",
    )
    parser.add_argument(
        "--stride-frames",
        type=int,
        default=env_or_default("OZTAL_STRIDE_FRAMES", 1, int),
        help="Window stride in original video frames. Use 1 for frame-by-frame sliding.",
    )
    parser.add_argument(
        "--resize",
        type=int,
        default=env_or_default("OZTAL_RESIZE", 224, int),
        help="Decoded frame size.",
    )
    parser.add_argument(
        "--device",
        default=env_or_default("OZTAL_DEVICE", "cuda"),
        help="Device for ViCLIP, such as cuda or cpu.",
    )
    parser.add_argument(
        "--video-batch-size",
        type=int,
        default=env_or_default("OZTAL_VIDEO_BATCH_SIZE", 8, int),
        help="Video windows encoded per GPU batch.",
    )
    parser.add_argument(
        "--viclip-repo",
        type=Path,
        default=env_path("OZTAL_VICLIP_REPO"),
        help="Local OpenGVLab/InternVideo repository path.",
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=env_path("OZTAL_CHECKPOINT"),
        help="Local ViCLIP checkpoint path.",
    )
    parser.add_argument(
        "--viclip-adapter",
        default=os.environ.get("OZTAL_VICLIP_ADAPTER"),
        help="Optional Python module exposing get_viclip/load_model/build_model.",
    )
    return parser.parse_args()


def main() -> None:
    started_at = datetime.now().astimezone()
    timer_start = time.perf_counter()
    args = parse_args()

    if args.viclip_repo is None:
        raise SystemExit("--viclip-repo is required")
    if args.checkpoint is None:
        raise SystemExit("--checkpoint is required")
    if args.window_frames <= 0:
        raise SystemExit("--window-frames must be > 0")
    if args.stride_frames != 1:
        raise SystemExit("Current video_windows.py uses frame-by-frame stride=1; set --stride-frames 1")

    print("ViCLIP video-only feature extraction")
    print(f"video: {args.video}")
    print("mode: original_fps_frame_by_frame")
    print(f"window_frames: {args.window_frames}")
    print(f"stride_frames: {args.stride_frames}")

    windows = decode_video_windows(
        video_path=args.video,
        num_frames=args.window_frames,
        resize=args.resize,
    )
    print(f"windows: {len(windows)}")

    backend = RealViCLIPBackend(
        repo_path=args.viclip_repo,
        checkpoint_path=args.checkpoint,
        device=args.device,
        adapter_module=args.viclip_adapter,
        video_batch_size=args.video_batch_size,
    )
    video_features = backend.encode_video_windows(windows)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    np.save(args.output_dir / "video_features.npy", video_features)

    metadata = {
        "video": str(args.video),
        "backend": "viclip",
        "viclip_repo": str(args.viclip_repo),
        "checkpoint": str(args.checkpoint),
        "checkpoint_name": args.checkpoint.name,
        "feature_extraction_mode": "original_fps_frame_by_frame",
        "window_frames": args.window_frames,
        "stride_frames": args.stride_frames,
        "resize": args.resize,
        "device": args.device,
        "video_batch_size": args.video_batch_size,
        "extracted_at": started_at.isoformat(timespec="seconds"),
        "elapsed_seconds": round(time.perf_counter() - timer_start, 3),
        "feature_shapes": {"video_features": list(video_features.shape)},
        "windows": [
            {
                "index": window.index,
                "start_seconds": window.start_seconds,
                "end_seconds": window.end_seconds,
                "start_frame": getattr(window, "start_frame", None),
                "end_frame": getattr(window, "end_frame", None),
            }
            for window in windows
        ],
    }
    (args.output_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"checkpoint: {args.checkpoint}")
    print(f"video_features: {list(video_features.shape)}")
    print(f"elapsed_seconds: {metadata['elapsed_seconds']}")
    print(f"saved to: {args.output_dir}")


if __name__ == "__main__":
    main()

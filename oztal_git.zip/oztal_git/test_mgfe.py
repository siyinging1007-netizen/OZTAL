from __future__ import annotations

import torch

from src.mgfe import MGFEModule


def main() -> None:
    video_features = torch.randn(81, 768)
    foreground_feature = torch.randn(768)
    background_feature = torch.randn(768)

    mgfe = MGFEModule(L_q=20, theta=0.8)
    enhanced_features = mgfe(video_features, foreground_feature, background_feature)

    print(f"video_features: {list(video_features.shape)}")
    print(f"foreground_feature: {list(foreground_feature.shape)}")
    print(f"background_feature: {list(background_feature.shape)}")
    print(f"enhanced_features: {list(enhanced_features.shape)}")


if __name__ == "__main__":
    main()

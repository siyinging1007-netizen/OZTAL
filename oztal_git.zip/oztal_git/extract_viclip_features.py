from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
from dotenv import load_dotenv

try:
    import torch
except ImportError:
    torch = None

from src.backends import FeatureBatch, RealViCLIPBackend, compute_viclip_batch, select_single_prompt_features
from src.deepseek_prompts import build_prompt_bank
from src.paths import STEP1_DIR, ensure_dir
from src.video_windows import decode_video_windows

load_dotenv("config.env", override=True, encoding="utf-8-sig")

FOREGROUND_DESCRIPTION = "A scene depicting a player engaging in some sports activities"
BACKGROUND_DESCRIPTION = "A scene without sports activities"

def read_classes(path: Path) -> list[str]:
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def env_or_default(name: str, default, cast=str):
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return cast(value)


def env_path(name: str) -> Path | None:
    value = os.environ.get(name)
    if value is None or value == "":
        return None
    return Path(value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract OZ-TAL first-step ViCLIP features using original DeepSeek one-sentence prompts."
    )
    parser.add_argument("--classes", type=Path, required=True, help="Text file with one action class per line.")
    parser.add_argument("--video", type=Path, default="videos/3.mp4", help="Video path for ViCLIP feature extraction.")
    parser.add_argument("--num-frames", type=int, default=env_or_default("OZTAL_NUM_FRAMES", 8, int), help="Frames sampled per temporal window.")
    parser.add_argument("--resize", type=int, default=env_or_default("OZTAL_RESIZE", 224, int), help="Decoded frame size.")
    parser.add_argument("--device", default=env_or_default("OZTAL_DEVICE", "cuda"), help="Device for ViCLIP, such as cuda or cpu.")
    parser.add_argument("--video-batch-size", type=int, default=env_or_default("OZTAL_VIDEO_BATCH_SIZE", 1, int), help="Video windows encoded per GPU batch.")
    parser.add_argument("--viclip-repo", type=Path, default=env_path("OZTAL_VICLIP_REPO"), help="Local OpenGVLab/InternVideo repository path.")
    parser.add_argument("--checkpoint", type=Path, default=env_path("OZTAL_CHECKPOINT"), help="Local ViCLIP checkpoint path.")
    parser.add_argument("--viclip-adapter", default=os.environ.get("OZTAL_VICLIP_ADAPTER"), help="Optional Python module exposing get_viclip/load_model/build_model.")
    parser.add_argument(
        "--prompt-mode",
        choices=("deepseek_sentence",),
        default=env_or_default("OZTAL_PROMPT_MODE", "deepseek_sentence"),
        help="Prompt source for action text features.",
    )
    parser.add_argument("--deepseek-model", default=env_or_default("OZTAL_DEEPSEEK_MODEL", "deepseek-v4-pro"), help="DeepSeek chat model name.")
    parser.add_argument(
        "--reuse-video-features",
        type=Path,
        help="Optional existing step1 directory or video_features.npy path. If set, skip video decoding/encoding and only rebuild text features.",
    )
    parser.add_argument(
        "--reuse-text-features",
        type=Path,
        help="Optional existing step1 directory. If set, reuse prompt/class/foreground/background text features.",
    )
    parser.add_argument("--output-dir", type=Path, default=STEP1_DIR, help="Directory used to save extracted features and metadata.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    classes = read_classes(args.classes)
    #创建prompt库 每个类别一句描述
    prompt_bank = build_prompt_bank(
        classes=classes,
        prompt_mode=args.prompt_mode,
        deepseek_model=args.deepseek_model,
        num_steps=3,
    )

    if args.reuse_video_features and args.reuse_text_features:
        reused_video_features = load_reused_video_features(args.reuse_video_features)
        video_windows = load_reused_windows(args.reuse_video_features)
        reused_text_features = load_reused_text_features(args.reuse_text_features, classes, prompt_bank)
        batch = FeatureBatch(
            video_features=reused_video_features,
            text_features=reused_text_features["prompt_text_features"],
            prompts=reused_text_features["prompts"],
            prompt_classes=reused_text_features["prompt_classes"],
        )
        class_text_features = reused_text_features["text_features"]
        foreground_feature = reused_text_features["foreground_feature"]
        background_feature = reused_text_features["background_feature"]
        reused_text_cache = True
    else:
        if args.reuse_text_features:
            raise SystemExit("--reuse-text-features currently requires --reuse-video-features")
        backend, video_windows, reused_video_features = build_backend_windows_and_reused_features(args)
        if reused_video_features is None:
            batch = compute_viclip_batch(
                video_windows=video_windows,
                classes=classes,
                backend=backend,
                prompt_bank=prompt_bank,
            )
        else:
            batch = compute_text_batch_from_reused_video_features(
                video_features=reused_video_features,
                classes=classes,
                backend=backend,
                prompt_bank=prompt_bank,
            )
        class_text_features = select_single_prompt_features(
            batch.text_features,
            batch.prompt_classes,
            classes,
        )
        foreground_feature, background_feature = encode_activity_semantics(backend)
        reused_text_cache = False

    print("OZ-TAL first-stage ViCLIP feature extraction")
    print(f"classes: {len(classes)}")
    print("backend: viclip")
    print(f"prompt_source: {args.prompt_mode}")
    if args.reuse_video_features:
        print(f"reuse_video_features: {args.reuse_video_features}")
    if args.reuse_text_features:
        print(f"reuse_text_features: {args.reuse_text_features}")
    print(f"prompts: {batch.prompts}")
    print(f"video_features V: {list(batch.video_features.shape)}  # [time_windows, feature_dim]")
    print(f"prompt_text_features T_prompt: {list(batch.text_features.shape)}")
    print(f"text_features T_class: {list(class_text_features.shape)}")
    print(f"foreground_feature f_a: {list(foreground_feature.shape)}")
    print(f"background_feature f_b: {list(background_feature.shape)}")
    if reused_text_cache:
        print("cos(f_a, f_b): reused")
    else:
        print(f"cos(f_a, f_b): {cosine_similarity(foreground_feature, background_feature):.4f}")
    print_feature_diagnostics(batch.video_features, class_text_features)
    print("No similarity scores are computed in this stage.")

    if args.output_dir:
        save_outputs(
            args.output_dir,
            args,
            classes,
            batch,
            class_text_features,
            video_windows,
            foreground_feature,
            background_feature,
        )
        print()
        print(f"Saved outputs to: {args.output_dir}")


def build_backend_windows_and_reused_features(args: argparse.Namespace):
    if args.checkpoint is None:
        raise SystemExit("--checkpoint is required")

    reused_video_features = None
    windows = None
    if args.reuse_video_features:
        reuse_path = resolve_reuse_video_features_path(args.reuse_video_features)
        reused_video_features = np.load(reuse_path).astype(np.float32)
        windows = load_reused_windows(args.reuse_video_features)
    else:
        if args.video is None:
            raise SystemExit("--video is required")
        windows = decode_video_windows(
            video_path=args.video,
            num_frames=args.num_frames,
            resize=args.resize,
        )
    backend = RealViCLIPBackend(
        repo_path=args.viclip_repo or args.checkpoint,
        checkpoint_path=args.checkpoint,
        device=args.device,
        adapter_module=args.viclip_adapter,
        video_batch_size=args.video_batch_size,
    )
    return backend, windows, reused_video_features


def resolve_reuse_video_features_path(path: Path) -> Path:
    if path.is_dir():
        path = path / "video_features.npy"
    if not path.exists():
        raise SystemExit(f"Reused video feature file not found: {path}")
    return path


def load_reused_video_features(path: Path) -> np.ndarray:
    return np.load(resolve_reuse_video_features_path(path)).astype(np.float32)


def load_reused_windows(path: Path) -> list[dict] | None:
    metadata_path = path / "metadata.json" if path.is_dir() else path.parent / "metadata.json"
    if not metadata_path.exists():
        return None
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    return metadata.get("windows")


def load_reused_text_features(path: Path, classes: list[str], prompt_bank: dict[str, list[str]]) -> dict:
    if not path.is_dir():
        raise SystemExit(f"Reused text feature path must be a step1 directory: {path}")

    required = {
        "prompt_text_features": path / "prompt_text_features.npy",
        "text_features": path / "text_features.npy",
        "foreground_feature": path / "foreground_feature.npy",
        "background_feature": path / "background_feature.npy",
    }
    missing = [str(feature_path) for feature_path in required.values() if not feature_path.exists()]
    if missing:
        raise SystemExit("Reused text feature files not found: " + ", ".join(missing))

    metadata_path = path / "metadata.json"
    if metadata_path.exists():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        prompts = metadata.get("prompts")
        prompt_classes = metadata.get("prompt_classes")
    else:
        prompts = None
        prompt_classes = None

    if prompts is None or prompt_classes is None:
        prompts = []
        prompt_classes = []
        for action in classes:
            for prompt in prompt_bank.get(action, []):
                prompts.append(prompt)
                prompt_classes.append(action)

    return {
        "prompt_text_features": np.load(required["prompt_text_features"]).astype(np.float32),
        "text_features": np.load(required["text_features"]).astype(np.float32),
        "foreground_feature": np.load(required["foreground_feature"]).astype(np.float32),
        "background_feature": np.load(required["background_feature"]).astype(np.float32),
        "prompts": prompts,
        "prompt_classes": prompt_classes,
    }


def compute_text_batch_from_reused_video_features(
    video_features: np.ndarray,
    classes: list[str],
    backend,
    prompt_bank: dict[str, list[str]],
):
    prompts = []
    prompt_classes = []
    for action in classes:
        for prompt in prompt_bank.get(action, []):
            prompts.append(prompt)
            prompt_classes.append(action)

    text_features = backend.encode_text_prompts(prompts)
    from src.backends import FeatureBatch

    return FeatureBatch(
        video_features=video_features,
        text_features=text_features,
        prompts=prompts,
        prompt_classes=prompt_classes,
    )


def encode_activity_semantics(backend) -> tuple[np.ndarray, np.ndarray]:
    semantic_features = backend.encode_text_prompts(
        [FOREGROUND_DESCRIPTION, BACKGROUND_DESCRIPTION]
    )
    return semantic_features[0], semantic_features[1]


def cosine_similarity(x: np.ndarray, y: np.ndarray) -> float:
    if torch is not None:
        x_tensor = torch.from_numpy(x).float()
        y_tensor = torch.from_numpy(y).float()
        return float(torch.nn.functional.cosine_similarity(x_tensor.unsqueeze(0), y_tensor.unsqueeze(0), dim=-1).item())
    return float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y)))


def print_feature_diagnostics(video_features: np.ndarray, text_features: np.ndarray) -> None:
    video_norms = np.linalg.norm(video_features, axis=1)
    text_norms = np.linalg.norm(text_features, axis=1)
    similarity = video_features @ text_features.T
    print(f"first 5 video feature norms: {video_norms[:5].round(6).tolist()}")
    print(f"all text feature norms: {text_norms.round(6).tolist()}")
    print(f"max video-text similarity: {float(similarity.max()):.6f}")


def save_outputs(
    output_dir: Path,
    args: argparse.Namespace,
    classes,
    batch,
    class_text_features: np.ndarray,
    video_windows,
    foreground_feature: np.ndarray,
    background_feature: np.ndarray,
) -> None:
    ensure_dir(output_dir)
    if args.reuse_video_features is None:
        np.save(output_dir / "video_features.npy", batch.video_features)
    np.save(output_dir / "prompt_text_features.npy", batch.text_features)
    np.save(output_dir / "text_features.npy", class_text_features)
    np.save(output_dir / "foreground_feature.npy", foreground_feature)
    np.save(output_dir / "background_feature.npy", background_feature)

    windows = []
    if video_windows is not None:
        for window in video_windows:
            if isinstance(window, dict):
                windows.append(
                    {
                        "index": window.get("index"),
                        "start_seconds": window.get("start_seconds"),
                        "end_seconds": window.get("end_seconds"),
                    }
                )
            else:
                windows.append(
                    {
                        "index": window.index,
                        "start_seconds": window.start_seconds,
                        "end_seconds": window.end_seconds,
                    }
                )

    metadata = {
        "backend": "viclip",
        "prompt_source": args.prompt_mode,
        "video": str(args.video),
        "viclip_repo": str(args.viclip_repo) if args.viclip_repo else None,
        "checkpoint": str(args.checkpoint) if args.checkpoint else None,
        "checkpoint_name": args.checkpoint.name if args.checkpoint else None,
        "reused_video_features": str(args.reuse_video_features) if args.reuse_video_features else None,
        "reused_text_features": str(args.reuse_text_features) if args.reuse_text_features else None,
        "deepseek_model": args.deepseek_model,
        "classes": classes,
        "prompts": batch.prompts,
        "prompt_classes": batch.prompt_classes,
        "foreground_description": FOREGROUND_DESCRIPTION,
        "background_description": BACKGROUND_DESCRIPTION,
        "windows": windows,
        "num_frames": args.num_frames,
        "resize": args.resize,
        "feature_shapes": {
            "video_features": list(batch.video_features.shape),
            "prompt_text_features": list(batch.text_features.shape),
            "text_features": list(class_text_features.shape),
            "foreground_feature": list(foreground_feature.shape),
            "background_feature": list(background_feature.shape),
        },
    }
    (output_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

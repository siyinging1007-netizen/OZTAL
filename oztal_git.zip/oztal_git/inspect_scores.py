from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from src.paths import STEP1_DIR, STEP2_DIR, STEP3_DIR


def normalize(x: np.ndarray) -> np.ndarray:
    return x / np.maximum(np.linalg.norm(x, axis=-1, keepdims=True), 1e-12)


def print_top_scores(name: str, scores: np.ndarray, classes: list[str], top_n: int = 20) -> None:
    print()
    print(name)
    flat_indices = np.argsort(scores.reshape(-1))[::-1][:top_n]
    for flat_index in flat_indices:
        window_index, class_index = np.unravel_index(flat_index, scores.shape)
        print(
            f"window {window_index:03d}  "
            f"{classes[class_index]:20s}  "
            f"score={scores[window_index, class_index]:8.4f}"
        )


def print_class_trace(name: str, scores: np.ndarray, classes: list[str], target_class: str) -> None:
    if target_class not in classes:
        return
    class_index = classes.index(target_class)
    print()
    print(f"{name}: {target_class}")
    for window_index in np.argsort(scores[:, class_index])[::-1][:20]:
        rank = int(np.argsort(scores[window_index])[::-1].tolist().index(class_index) + 1)
        print(
            f"window {window_index:03d}  "
            f"rank={rank:02d}  "
            f"score={scores[window_index, class_index]:8.4f}"
        )


def main() -> None:
    metadata = json.loads((STEP1_DIR / "metadata.json").read_text(encoding="utf-8"))
    classes = metadata["classes"]
    windows = metadata.get("windows", [])

    video = normalize(np.load(STEP1_DIR / "video_features.npy").astype(np.float32))
    text = normalize(np.load(STEP1_DIR / "text_features.npy").astype(np.float32))
    enhanced = normalize(np.load(STEP2_DIR / "enhanced_video_features.npy").astype(np.float32))
    y = np.load(STEP3_DIR / "y_scores.npy").astype(np.float32)

    raw_scores = 100.0 * (video @ text.T)
    enhanced_scores = 100.0 * (enhanced @ text.T)

    print(f"windows: {len(windows)}")
    if windows:
        print(f"time range: {windows[0]['start_seconds']:.2f}s -> {windows[-1]['end_seconds']:.2f}s")
    print(f"raw score min/max/mean: {raw_scores.min():.4f} / {raw_scores.max():.4f} / {raw_scores.mean():.4f}")
    print(
        "enhanced score min/max/mean: "
        f"{enhanced_scores.min():.4f} / {enhanced_scores.max():.4f} / {enhanced_scores.mean():.4f}"
    )
    print(f"BAKC y min/max/mean: {y.min():.4f} / {y.max():.4f} / {y.mean():.4f}")

    print_top_scores("Step 1 raw ViCLIP similarity logits", raw_scores, classes)
    print_top_scores("Step 2 enhanced ViCLIP similarity logits", enhanced_scores, classes)
    print_top_scores("Step 3 BAKC y scores", y, classes)

    print_class_trace("Step 1 raw", raw_scores, classes, "long jump")
    print_class_trace("Step 2 enhanced", enhanced_scores, classes, "long jump")
    print_class_trace("Step 3 BAKC", y, classes, "long jump")


if __name__ == "__main__":
    main()

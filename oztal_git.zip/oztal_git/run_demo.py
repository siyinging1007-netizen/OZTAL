from extract_viclip_features import main


if __name__ == "__main__":
    main()

# 实验配置

## 数据集

- 数据集：THUMOS14 test set 213 个视频
- Zero-shot零样本类别分割：75%-25% 共20个类别，选取5个类别进行测试
- Unseen 类别（5 个）：
  - `CliffDiving`
  - `VolleyballSpiking`
  - `TennisSwing`
  - `SoccerPenalty`
  - `FrisbeeCatch`
- 对应测试视频数量：56 个

## 模型配置

- 视觉-语言大模型：ViCLIP
- 视频输入resize：224x224
- 特征维度：768
- 大语言模型：deepseek-v4-pro 为动作类别生成描述性句子
- Prompt：
 ```"role": "system",
                    "content": (
                        "Given an action, please write a short description summarizing "
                        "the key components of the action, following these two requirements: "
                        "1. The description should differentiate the action from other actions. "
                        "2. Avoid using adverbs and obscure words. "
                        "Output the answer in this JSON format: {\"<action>\": \"<description>\"}"
                    ),
  ```
                    
## 视频切窗参数

- 窗口长度：`2.0s`
- 滑窗步长：`0.25s`
- 每窗口采样帧数：`8`
- 每个窗口输入形状：`[8, 224, 224, 3]`
- 窗口生成方式：
  - 从视频起点开始按 `0.25s` 滑动
  - 每个窗口覆盖 `2.0s`
  - 每个窗口内均匀采样 8 帧

## 前景/背景语义描述

当前代码位置：

- `extract_viclip_features.py`

当前前景描述：

```text
A video segment where a person is actively performing a sports action 
```

当前背景描述：

```text
A video segment where no target sports action is happening, such as preparation, waiting
```

这两个描述会被 ViCLIP 编码为：

- `foreground_feature.npy`
- `background_feature.npy`

它们用于：

- MGFE：判断当前窗口是否更像前景动作
- BAKC：计算背景置信度并惩罚背景窗口

## 超参数

### MGFE

- 模块：Memory-Guided Feature Enhancement
- 代码位置：`src/mgfe.py`
- 运行入口：`run_mgfe.py`
- 记忆队列长度 `L_q`：`20`
- 相似度阈值 `theta`：`0.8`
- 记忆队列内容：只保存更像前景的窗口特征
- 特征融合：当前特征 `x_t` 与时间加权记忆特征 `q_tilde` 融合

### BAKC

- 模块：Background-Aware K-way Classification
- 代码位置：`src/bakc.py`
- 运行入口：`run_bakc.py`
- 分数缩放系数 `scale`：`100.0`
- 分类输入：
  - `enhanced_video_features.npy`
  - `text_features.npy`
  - `background_feature.npy`
- 输出：
  - `k_logits.npy`
  - `r_background.npy`
  - `alpha.npy`
  - `y_scores.npy`

### Span Prediction

- 模块：Online Action Span Prediction
- 代码位置：`src/span_prediction.py`
- 运行入口：`run_span_prediction.py`
- 动作判定阈值 `tau`：`10.0`
- 判定规则：若 `y_scores[t, k] > tau`，则窗口 `t` 中类别 `k` 被判定为激活
- 片段生成：
  - 状态从 0 到 1：动作开始
  - 状态从 1 到 0：动作结束
- 置信度：片段内该类别分数求和，再除以片段长度平方根

## 批量推理配置

- 批量脚本：`run_batch.py`
- 单视频流水线脚本：`run_pipeline.py`
- 视频列表：`video_list.txt`
- 默认输出目录：`output/batch_exp001`
- 每个视频单独输出目录格式：
  - `output/batch_exp001/video_test_0000006`
- 断点续跑判断文件：
  - `step4_span_prediction/results.json`
- 若该文件已存在：跳过该视频
- 若某个视频失败：打印 warning，继续处理下一个视频
- 全部完成后汇总：
  - `output/batch_exp001/all_results.json`

推荐运行命令：

```powershell
D:\anaconda3\envs\viclip\python.exe run_batch.py --classes examples\classes.txt --device cuda --video-dir "D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\selected_56_videos"
```

## 输出格式

### 单视频最终输出

路径示例：

```text
output/batch_exp001/video_test_0000006/step4_span_prediction/results.json
```

格式：

```json
[
  {
    "start": 2,
    "end": 10,
    "category": "VolleyballSpiking",
    "confidence": 35.912845611572266,
    "start_seconds": 0.5,
    "end_seconds": 4.5
  }
]
```

### 批量汇总输出

路径：

```text
output/batch_exp001/all_results.json
```

格式：

```json
{
  "video_test_0000006": [
    {
      "category": "VolleyballSpiking",
      "confidence": 35.912845611572266,
      "start_seconds": 0.5,
      "end_seconds": 4.5
    }
  ]
}
```

## 评估配置

- 评估脚本：`eval_map.py`
- 预测文件：`output/batch_exp001/all_results.json`
- 标注文件格式：`{ClassName}_test.txt`
- 标注行格式：`video_test_0000006  10.5  13.5`
- tIoU 阈值：
  - `0.3`
  - `0.4`
  - `0.5`
  - `0.6`
  - `0.7`
- 评估指标：
  - 每个类别 AP
  - 每个 tIoU 阈值下的 mAP
  - 5 个 tIoU 阈值的平均 mAP

推荐评估命令：

```powershell
D:\anaconda3\envs\viclip\python.exe eval_map.py --predictions output\batch_exp001\all_results.json --annotation-dir "D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_Temporal_annotations_test\annotation" --classes examples\classes.txt
```

> 注：评估这 5 个 unseen 类别时应使用 `examples/classes.txt`，不要使用 `examples/thumos14_classes.txt`。

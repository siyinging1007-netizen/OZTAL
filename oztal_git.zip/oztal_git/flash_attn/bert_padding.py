def unpad_input(*args, **kwargs):
    raise RuntimeError(
        "flash-attn is not installed. The model should not call unpad_input "
        "when flash attention is disabled."
    )


def pad_input(*args, **kwargs):
    raise RuntimeError(
        "flash-attn is not installed. The model should not call pad_input "
        "when flash attention is disabled."
    )

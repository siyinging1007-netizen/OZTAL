class FusedMLP:
    def __init__(self, *args, **kwargs):
        raise RuntimeError(
            "flash-attn is not installed. The model should not instantiate "
            "FusedMLP when fused MLP is disabled."
        )

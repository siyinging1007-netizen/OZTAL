"""Compatibility shim for flash_attn.modules."""

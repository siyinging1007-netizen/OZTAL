"""Compatibility shim for Windows environments without flash-attn."""

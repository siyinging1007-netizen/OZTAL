def flash_attn_varlen_qkvpacked_func(*args, **kwargs):
    raise RuntimeError(
        "flash-attn is not installed. This project disables flash attention in "
        "the InternVideo2 config; if this function is called, the loaded model "
        "still requires a real flash-attn installation."
    )

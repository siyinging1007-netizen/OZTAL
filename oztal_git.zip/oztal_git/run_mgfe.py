from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from src.mgfe import MGFEModule
from src.paths import STEP1_DIR, STEP2_DIR, ensure_dir


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run OZ-TAL step 2: Memory-Guided Feature Enhancement."
    )
    parser.add_argument(
        "--video-features",
        type=Path,
        required=False,
        help="Path to first-step video feature file (.npy), shape [T, D].",
    )
    parser.add_argument(
        "--foreground-feature",
        type=Path,
        required=False,
        help="Path to foreground semantic feature (.npy), shape [D].",
    )
    parser.add_argument(
        "--background-feature",
        type=Path,
        required=False,
        help="Path to background semantic feature (.npy), shape [D].",
    )
    parser.add_argument(
        "--output-path",
        type=Path,
        default=STEP2_DIR / "enhanced_video_features.npy",
        help="Path to save enhanced features (.npy).",
    )
    parser.add_argument("--memory-size", type=int, default=20, help="Maximum queue length L_q.")
    parser.add_argument("--theta", type=float, default=0.8, help="Enhancement threshold.")
    parser.add_argument(
        "--metadata-path",
        type=Path,
        help="Optional metadata.json path to update with MGFE output info.",
    )
    parser.add_argument(
        "--feature-dir",
        type=Path,
        default=STEP1_DIR,
        help="Directory containing first-step outputs. If provided, default input paths are resolved from it.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.feature_dir:
        args.video_features = args.video_features or (args.feature_dir / "video_features.npy")
        args.foreground_feature = args.foreground_feature or (args.feature_dir / "foreground_feature.npy")
        args.background_feature = args.background_feature or (args.feature_dir / "background_feature.npy")
        args.metadata_path = args.metadata_path or (args.feature_dir / "metadata.json")
    if args.video_features is None or args.foreground_feature is None or args.background_feature is None:
        raise SystemExit("video, foreground, and background feature paths are required.")

    video_features = torch.from_numpy(np.load(args.video_features)).float()
    foreground_feature = torch.from_numpy(np.load(args.foreground_feature)).float()
    background_feature = torch.from_numpy(np.load(args.background_feature)).float()

    module = MGFEModule(L_q=args.memory_size, theta=args.theta)
    enhanced_features = module(video_features, foreground_feature, background_feature)

    ensure_dir(args.output_path.parent)
    np.save(args.output_path, enhanced_features.cpu().numpy().astype(np.float32))
    np.save(args.output_path.parent / "foreground_feature.npy", foreground_feature.cpu().numpy().astype(np.float32))
    np.save(args.output_path.parent / "background_feature.npy", background_feature.cpu().numpy().astype(np.float32))

    print("OZ-TAL step 2: Memory-Guided Feature Enhancement")
    print(f"video_features: {list(video_features.shape)}")
    print(f"foreground_feature: {list(foreground_feature.shape)}")
    print(f"background_feature: {list(background_feature.shape)}")
    print(f"enhanced_features: {list(enhanced_features.shape)}")

    if args.metadata_path and args.metadata_path.exists():
        metadata = json.loads(args.metadata_path.read_text(encoding="utf-8"))
        metadata.setdefault("feature_shapes", {})
        metadata["feature_shapes"]["enhanced_video_features"] = list(enhanced_features.shape)
        metadata["mgfe"] = {
            "L_q": args.memory_size,
            "theta": args.theta,
            "output_path": str(args.output_path),
        }
        metadata_output_path = args.output_path.parent / "metadata.json"
        metadata_output_path.write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()

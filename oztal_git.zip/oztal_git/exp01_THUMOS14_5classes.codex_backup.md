﻿# 实验笔记：exp01_THUMOS14_5classes

## 1. 实验目标

复现 OZ-TAL: Online Zero-Shot Temporal Action Localization 在 THUMOS14 test set 上的零样本时序动作定位流程。

当前实验使用 5 个 unseen 类别：

```text
CliffDiving
VolleyballSpiking
TennisSwing
SoccerPenalty
FrisbeeCatch
```

类别文件：

```text
D:\ZYY\viclip_oz_tal_repro\examples\classes.txt
```

## 2. 数据与路径

| 项目 | 路径 / 数值 |
|---|---|
| 项目目录 | `D:\ZYY\viclip_oz_tal_repro` |
| THUMOS14 213 个测试视频目录 | `D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_test_set_213_mp4` |
| 标注目录 | `D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_Temporal_annotations_test\annotation` |
| 当前视频列表 | `D:\ZYY\viclip_oz_tal_repro\video_list.txt` |
| 当前已缓存视频特征目录 | `D:\ZYY\viclip_oz_tal_repro\output\frame_video_features` |
| 当前推理输出目录 | `D:\ZYY\viclip_oz_tal_repro\output\frame_features_results` |
| 当前汇总预测文件 | `D:\ZYY\viclip_oz_tal_repro\output\frame_features_results\all_results.json` |

当前 `output\frame_video_features` 下统计到 57 个视频子目录，其中当前 `video_list.txt` 推理后 `all_results.json` 覆盖 56 个视频。

## 3. 模型与权重

| 项目 | 配置 |
|---|---|
| 视觉编码器 | ViCLIP-L / ViT-L/16 |
| ViCLIP repo | `D:\ZYY\InternVideo-main` |
| 权重文件 | `D:\ZYY\ViCLIP-L_InternVid-FLT-10M.pth` |
| checkpoint name | `ViCLIP-L_InternVid-FLT-10M.pth` |
| device | `cuda` |
| Python 环境 | `D:\anaconda3\envs\viclip\python.exe` |

注意：不要使用系统默认 `python`，该环境曾出现 `No module named 'encodings'`。

## 4. 当前四步流程

当前运行的是完整四步推理，但第 1 步复用了已经提取好的视频特征：

```text
step1: 复用 video_features.npy + 生成/复用文本特征
step2: MGFE
step3: BAKC
step4: span prediction
```

当前命令：

```powershell
cd "D:\ZYY\viclip_oz_tal_repro"

D:\anaconda3\envs\viclip\python.exe run_batch.py `
  --video-list video_list.txt `
  --video-dir "D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_test_set_213_mp4" `
  --classes examples\classes.txt `
  --output-root output\frame_features_results `
  --device cuda `
  --viclip-repo "D:\ZYY\InternVideo-main" `
  --checkpoint "D:\ZYY\ViCLIP-L_InternVid-FLT-10M.pth" `
  --reuse-feature-root output\frame_video_features
```

`--reuse-feature-root` 表示复用：

```text
output\frame_video_features\video_test_xxxxxxx\video_features.npy
```

`run_batch.py` 会在第一个视频生成文本特征，之后视频自动复用文本特征。

## 5. Step1 特征与文本 prompt

以 `video_test_0000006` 为例：

```text
reuse_video_features: output\frame_video_features\video_test_0000006\video_features.npy
video_features V: [2003, 768]
prompt_text_features T_prompt: [5, 768]
text_features T_class: [5, 768]
foreground_feature f_a: [768]
background_feature f_b: [768]
cos(f_a, f_b): 0.5437
max video-text similarity: 0.190278
```

说明：当前没有重新提取视频特征，只是复用已有 `video_features.npy`，并补齐文本特征。

当前 prompt source：

```text
prompt_source: deepseek_sentence
deepseek_model: deepseek-v4-pro
```

当前 5 类文本 prompt：

| 类别 | prompt |
|---|---|
| CliffDiving | Jumping from a high cliff into water with a controlled dive |
| VolleyballSpiking | Jumping and striking a ball downward over a net into the opponent's court |
| TennisSwing | Swinging a racket to hit a ball over a net |
| SoccerPenalty | Kicking a stationary ball from the penalty mark toward the goal with only the goalkeeper defending |
| FrisbeeCatch | Securing a flying disc with one or both hands |

当前 foreground/background 描述：

```python
FOREGROUND_DESCRIPTION = "Temporal body motion with limb swing, jump, fall, kick, strike, reach, or catch"
BACKGROUND_DESCRIPTION = "Sports venue environment including audience seats, scoreboard, referee, idle players, or replay footage"
```

当前观察：`cos(f_a, f_b)=0.5437` 偏高，说明前景/背景文本语义没有完全拉开。

## 6. 当前窗口设置

当前缓存特征来自逐帧滑动窗口方案。以 `video_test_0000006` metadata 为例：

```text
window 0: 0.0000s -> 0.2667s
window 1: 0.0333s -> 0.3000s
window 2: 0.0667s -> 0.3333s
```

对应约为：

```text
window_frames = 8
stride_frames = 1
```

这与当前代码/缓存特征一致。

## 7. Step3 BAKC 参数与公式

BAKC 入口：

```text
D:\ZYY\viclip_oz_tal_repro\run_bakc.py
```

核心公式位于：

```text
D:\ZYY\viclip_oz_tal_repro\src\bakc.py
```

当前公式：

```python
y = alpha * k - (1.0 - alpha) * r.unsqueeze(1)
```

当前 scale：

```text
scale = 100.0
```

以 `video_test_0000006` 为例，step3 输出形状：

```text
k:     [2003, 5]
r:     [2003]
alpha: [2003, 5]
y:     [2003, 5]
```

## 8. Step4 Span Prediction 参数

当前 tau：

```text
tau = 10.0
```

规定位置：

```text
D:\ZYY\viclip_oz_tal_repro\run_pipeline.py
D:\ZYY\viclip_oz_tal_repro\run_span_prediction.py
```

当前 `video_test_0000006` 的 step4 metadata：

```json
{
  "tau": 10.0,
  "num_instances": 5,
  "state_matrix_shape": [2003, 5]
}
```

`tau` 作用在 step3 的窗口级 `y_scores.npy` 上，不是直接作用在最终片段 confidence 上。

`video_test_0000006` 的 `y_scores.npy` 统计：

```text
shape = (2003, 5)
min = -5.1855674
max = 16.153135
mean = 0.80786854
>10 = 145
>20 = 0
>30 = 0
>50 = 0
```

## 9. 当前 mAP 结果

评估命令：

```powershell
cd "D:\ZYY\viclip_oz_tal_repro"

D:\anaconda3\envs\viclip\python.exe eval_map.py `
  --predictions "D:\ZYY\viclip_oz_tal_repro\output\frame_features_results\all_results.json" `
  --annotation-dir "D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_Temporal_annotations_test\annotation" `
  --classes examples\classes.txt
```

当前结果：

| tIoU | mAP |
|---|---:|
| 0.3 | 8.58% |
| 0.4 | 4.27% |
| 0.5 | 2.49% |
| 0.6 | 1.17% |
| 0.7 | 0.49% |
| Avg | 3.40% |

`tIoU=0.5` 每类 AP：

| 类别 | AP@0.5 |
|---|---:|
| CliffDiving | 4.02% |
| VolleyballSpiking | 3.92% |
| TennisSwing | 0.00% |
| SoccerPenalty | 2.95% |
| FrisbeeCatch | 1.56% |

## 10. BAKC 数值诊断

当前怀疑点：部分视频的背景分数 `r` 过高，导致：

```python
y = alpha * k - (1.0 - alpha) * r
```

中的背景惩罚过强，动作分数被压低。

### 10.1 video_test_0000006

```text
k:     min=0.13   max=19.00  mean=9.15
r:     min=-4.70  max=12.65  mean=9.35
alpha: min=0.50   max=1.00   mean=0.57
y:     min=-5.19  max=16.15  mean=0.81
```

结论：该视频 `r mean=9.35`，已经高于 `k mean=9.15`，背景惩罚明显压制动作分数。

### 10.2 video_test_0000211

```text
k:     min=-0.93  max=20.46  mean=11.32
r:     min=0.82   max=20.54  mean=11.71
alpha: min=0.50   max=0.89   mean=0.55
y:     min=-8.31  max=13.47  mean=0.86
```

结论：该视频也存在 `r` 接近或超过 `k` 的问题，`y` 被压得很低。

### 10.3 对照视频

`video_test_0000026`：

```text
k mean=11.71
r mean=2.86
alpha mean=0.80
y mean=9.01
y max=25.18
```

`video_test_0000724`：

```text
k mean=8.04
r mean=-3.29
alpha mean=0.84
y mean=8.35
y max=29.22
```

结论：背景惩罚不是所有视频都高，但在部分视频上很严重。

### 10.4 全 56 个视频整体统计

```text
k:     min=-10.43  max=30.89  mean=9.84
r:     min=-10.90  max=20.54  mean=3.58
alpha: min=0.50    max=1.00   mean=0.72
y:     min=-11.60  max=30.89  mean=6.05
```

结论：全局平均 `r` 不算特别高，但部分视频中 `r` 与动作分数混淆严重。

## 11. 当前问题总结

1. 当前 mAP 明显偏低，Avg mAP 为 `3.40%`。
2. `TennisSwing` 在 `tIoU=0.5` 下 AP 为 `0.00%`，该类定位失败最明显。
3. 部分视频中 `r_background` 过高，导致 BAKC 把动作分数压低。
4. 当前 foreground/background 文本区分度不足，`cos(f_a, f_b)=0.5437` 偏高。
5. 当前 step4 使用简单阈值切段：`y > tau`，没有额外 NMS、相邻片段合并、最小时长过滤或 top-k 限制。

## 12. 下一步消融实验计划

### 12.1 背景惩罚强度消融

保留原论文公式作为 baseline：

```python
y = alpha * k - (1.0 - alpha) * r.unsqueeze(1)
```

新增消融参数：

```python
lambda_bg = 0.5
y = alpha * k - lambda_bg * (1.0 - alpha) * r.unsqueeze(1)
```

建议实验：

```text
lambda_bg = 1.0  原始 BAKC
lambda_bg = 0.5  背景惩罚减半
lambda_bg = 0.3  背景惩罚更弱
lambda_bg = 0.0  去掉背景扣分，仅做对照
```

### 12.2 foreground/background 描述消融

当前背景描述可能把动作场景中的观众、场地、裁判、idle players 等共同出现元素也吸进去，导致 `r` 偏高。

建议新版本：

```python
FOREGROUND_DESCRIPTION = (
    "A person performing a clear sports action with strong body motion, "
    "including diving, spiking, swinging, kicking, or catching"
)

BACKGROUND_DESCRIPTION = (
    "Static non-action footage with no athlete performing the target action, "
    "including empty field, audience, scoreboard, logo screen, replay transition, or idle scene"
)
```

### 12.3 tau 消融

当前 `tau=10`。由于 `video_test_0000006` 的 `y max=16.15`，不建议直接设到 20。

建议先试：

```text
tau = 11
tau = 12
tau = 14
tau = 15
```

但从当前诊断看，只调 tau 不能根治背景惩罚和语义混淆问题。

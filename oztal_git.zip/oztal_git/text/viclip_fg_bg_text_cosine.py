from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

import numpy as np
DEFAULT_PAIRS = [
    {
        "name": "10",
        "foreground": "Limb acceleration, airborne body, projectile arc, or forceful contact between athlete and object",
        "background": "Net mesh, goalpost, lane markings, diving platform, grandstand, broadcast caption, and sky",
    },
    {
        "name": "11",
        "foreground": "Explosive joint extension, rapid limb swing, body rotation, or mid-air suspension of athlete",
        "background": "Fixed structural elements including fencing, water surface, court boundary, seating rows, and scoreboard",
    },
    {
        "name": "12",
        "foreground": "Athlete executing peak technique with visible speed and force in competitive sport",
        "background": "Sideline, bench area, empty field, replay graphic, or spectator stand with no active play",
    },
    {
        "name": "13",
        "foreground": "High-speed athletic movement captured at moment of maximum physical output",
        "background": "Stadium infrastructure, crowd seating, referee position, transition shot, or slow-motion replay",
    },
    {
        "name": "14",
        "foreground": "Fast limb movement and body displacement of competitor during decisive sport technique execution",
        "background": "Venue boundary structures, audience area, preparation zone, broadcast overlay, and non-playing personnel",
    },
]
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compute foreground/background text similarity with ViCLIP text features only."
    )
    parser.add_argument("--pairs", type=Path, help="JSON file: [{name, foreground, background}].")
    parser.add_argument("--project-root", type=Path, default=Path(r"D:\ZYY\viclip_oz_tal_repro"))
    parser.add_argument("--viclip-repo", type=Path, default=Path(r"D:\ZYY\InternVideo-main"))
    parser.add_argument("--checkpoint", type=Path, default=Path(r"D:\ZYY\ViCLIP-L_InternVid-FLT-10M.pth"))
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--output-csv", type=Path, default=Path("outputs/viclip_fg_bg_text_cosine2.csv"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    pairs = load_pairs(args.pairs)
    rows = build_rows(pairs)
    add_viclip_cosines(rows, args)
    save_csv(rows, args.output_csv)
    print_rows(rows)
    print(f"\nSaved: {args.output_csv}")


def load_pairs(path: Path | None) -> list[dict[str, str]]:
    if path is None:
        return DEFAULT_PAIRS
    return json.loads(path.read_text(encoding="utf-8"))


def build_rows(pairs: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for pair in pairs:
        fg_tokens = tokenize(pair["foreground"])
        bg_tokens = tokenize(pair["background"])
        overlap = sorted(fg_tokens & bg_tokens)
        union = fg_tokens | bg_tokens
        rows.append(
            {
                "name": pair["name"],
                "lexical_jaccard": round(len(overlap) / max(1, len(union)), 6),
                "overlap_count": len(overlap),
                "overlap_words": " ".join(overlap),
                "viclip_cosine": "",
                "foreground": pair["foreground"],
                "background": pair["background"],
            }
        )
    return rows


def tokenize(text: str) -> set[str]:
    stop_words = {"a", "an", "the", "and", "or", "with", "where", "such", "as", "is", "are"}
    return {
        token
        for token in re.findall(r"[a-z]+", text.lower())
        if token not in stop_words
    }


def add_viclip_cosines(rows: list[dict[str, object]], args: argparse.Namespace) -> None:
    sys.path.insert(0, str(args.project_root))
    from src.backends import RealViCLIPBackend

    backend = RealViCLIPBackend(
        repo_path=args.viclip_repo,
        checkpoint_path=args.checkpoint,
        device=args.device,
    )
    prompts: list[str] = []
    for row in rows:
        prompts.append(str(row["foreground"]))
        prompts.append(str(row["background"]))

    features = backend.encode_text_prompts(prompts)
    for index, row in enumerate(rows):
        fg = features[index * 2]
        bg = features[index * 2 + 1]
        row["viclip_cosine"] = round(cosine(fg, bg), 6)


def cosine(x: np.ndarray, y: np.ndarray) -> float:
    return float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y)))


def save_csv(rows: list[dict[str, object]], output_csv: Path) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def print_rows(rows: list[dict[str, object]]) -> None:
    for row in rows:
        print(
            f"{row['name']}: "
            f"viclip_cosine={row['viclip_cosine']} "
            f"lexical_jaccard={row['lexical_jaccard']} "
            f"overlap_count={row['overlap_count']}"
        )
        if row["overlap_words"]:
            print(f"  overlap_words: {row['overlap_words']}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the full OZ-TAL ViCLIP pipeline: feature extraction -> MGFE -> BAKC -> span prediction."
    )
    parser.add_argument("--classes", type=Path, default=Path("examples/classes.txt"), help="Text file with one class per line.")
    parser.add_argument("--video", type=Path, default=Path("videos/3.mp4"), help="Input video path.")
    parser.add_argument("--output-root", type=Path, default=Path("output/exp001"), help="Root directory for all step outputs.")

    parser.add_argument("--start-step", type=int, choices=(1, 2, 3, 4), default=1, help="First step to run.")
    parser.add_argument("--end-step", type=int, choices=(1, 2, 3, 4), default=4, help="Last step to run.")

    parser.add_argument("--num-frames", type=int, help="Frames sampled per temporal window for step 1.")
    parser.add_argument("--resize", type=int, help="Decoded frame size for step 1.")
    parser.add_argument("--device", help="Device for ViCLIP, such as cuda or cpu.")
    parser.add_argument("--video-batch-size", type=int, help="Video windows encoded per GPU batch.")
    parser.add_argument("--viclip-repo", type=Path, help="Local OpenGVLab/InternVideo repository path.")
    parser.add_argument("--checkpoint", type=Path, help="Local ViCLIP checkpoint path.")
    parser.add_argument("--viclip-adapter", help="Optional Python module exposing get_viclip/load_model/build_model.")
    parser.add_argument("--prompt-mode", choices=("deepseek_sentence",), help="Prompt source for step 1 text features.")
    parser.add_argument("--deepseek-model", help="DeepSeek chat model name.")
    parser.add_argument(
        "--reuse-video-features",
        type=Path,
        help="Existing step1 directory or video_features.npy path. Step 1 skips video encoding and rebuilds text features.",
    )
    parser.add_argument(
        "--reuse-text-features",
        type=Path,
        help="Existing step1 directory. Step 1 reuses prompt/class/foreground/background text features.",
    )

    parser.add_argument("--memory-size", type=int, default=20, help="MGFE memory queue length L_q.")
    parser.add_argument("--theta", type=float, default=0.8, help="MGFE enhancement threshold.")
    parser.add_argument("--scale", type=float, default=100.0, help="BAKC temperature scale.")
    parser.add_argument("--tau", type=float, default=10.0, help="Span prediction threshold.")
    args = parser.parse_args()

    if args.start_step > args.end_step:
        parser.error("--start-step must be <= --end-step")
    return args


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parent
    output_root = args.output_root
    step1_dir = output_root / "step1_feature_extraction"
    step2_dir = output_root / "step2_mgfe"
    step3_dir = output_root / "step3_bakc"
    step4_dir = output_root / "step4_span_prediction"

    if args.start_step <= 1 <= args.end_step:
        command = [
            sys.executable,
            "extract_viclip_features.py",
            "--classes",
            str(args.classes),
            "--video",
            str(args.video),
            "--output-dir",
            str(step1_dir),
        ]
        append_optional(command, "--num-frames", args.num_frames)
        append_optional(command, "--resize", args.resize)
        append_optional(command, "--device", args.device)
        append_optional(command, "--video-batch-size", args.video_batch_size)
        append_optional(command, "--viclip-repo", args.viclip_repo)
        append_optional(command, "--checkpoint", args.checkpoint)
        append_optional(command, "--viclip-adapter", args.viclip_adapter)
        append_optional(command, "--prompt-mode", args.prompt_mode)
        append_optional(command, "--deepseek-model", args.deepseek_model)
        append_optional(command, "--reuse-video-features", args.reuse_video_features)
        append_optional(command, "--reuse-text-features", args.reuse_text_features)
        run_step("step 1: ViCLIP feature extraction", command, project_root)

    if args.start_step <= 2 <= args.end_step:
        command = [
            sys.executable,
            "run_mgfe.py",
            "--feature-dir",
            str(step1_dir),
            "--output-path",
            str(step2_dir / "enhanced_video_features.npy"),
            "--memory-size",
            str(args.memory_size),
            "--theta",
            str(args.theta),
        ]
        if args.reuse_video_features:
            command.extend(
                [
                    "--video-features",
                    str(resolve_reuse_video_features_path(args.reuse_video_features)),
                ]
            )
        run_step("step 2: MGFE", command, project_root)

    if args.start_step <= 3 <= args.end_step:
        run_step(
            "step 3: BAKC",
            [
                sys.executable,
                "run_bakc.py",
                "--step1-dir",
                str(step1_dir),
                "--step2-dir",
                str(step2_dir),
                "--output-dir",
                str(step3_dir),
                "--scale",
                str(args.scale),
            ],
            project_root,
        )

    if args.start_step <= 4 <= args.end_step:
        run_step(
            "step 4: span prediction",
            [
                sys.executable,
                "run_span_prediction.py",
                "--step3-dir",
                str(step3_dir),
                "--output-dir",
                str(step4_dir),
                "--tau",
                str(args.tau),
            ],
            project_root,
        )

    print()
    print(f"Pipeline finished. Outputs are under: {output_root}")


def append_optional(command: list[str], flag: str, value: object | None) -> None:
    if value is not None:
        command.extend([flag, str(value)])


def resolve_reuse_video_features_path(path: Path) -> Path:
    return path / "video_features.npy" if path.is_dir() else path


def run_step(name: str, command: list[str], cwd: Path) -> None:
    print()
    print(f"=== {name} ===")
    print(format_command(command))
    subprocess.run(command, cwd=cwd, check=True)


def format_command(command: list[str]) -> str:
    return " ".join(f'"{part}"' if " " in part else part for part in command)


if __name__ == "__main__":
    main()

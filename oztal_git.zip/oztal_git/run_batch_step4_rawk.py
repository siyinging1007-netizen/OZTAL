from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


DEFAULT_VIDEO_DIR = Path(r"D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_test_set_mp4")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Batch rerun span prediction directly from raw k logits, bypassing BAKC."
    )
    parser.add_argument("--video-list", type=Path, default=Path("video_list.txt"), help="Text file with one video filename per line.")
    parser.add_argument("--video-dir", type=Path, default=DEFAULT_VIDEO_DIR, help="Directory containing original videos. Only used for naming.")
    parser.add_argument("--input-root", type=Path, required=True, help="Existing batch root that already contains step3_bakc.")
    parser.add_argument("--step4-name", default="step4_rawk_tau7", help="Output subdirectory name for rerun step 4 results.")
    parser.add_argument("--tau", type=float, default=7.0, help="Threshold passed to raw-k span prediction.")
    parser.add_argument("--python", default=sys.executable, help="Python executable used to run run_span_prediction_rawk.py.")
    parser.add_argument("--script", type=Path, default=Path("run_span_prediction_rawk.py"), help="Raw-k step 4 script path.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parent
    video_names = read_video_list(resolve_path(args.video_list, project_root))
    total = len(video_names)
    failed: list[str] = []

    for index, video_name in enumerate(video_names, start=1):
        video_stem = Path(video_name).stem
        video_root = args.input_root / video_stem
        step3_dir = video_root / "step3_bakc"
        step4_dir = video_root / args.step4_name
        result_path = step4_dir / "results.json"

        if not step3_dir.exists():
            failed.append(video_stem)
            print(f"WARNING: [{index}/{total}] {video_stem} missing step3_bakc; continue")
            continue

        if result_path.exists():
            print(f"[{index}/{total}] {video_stem} skipped")
            continue

        command = [
            args.python,
            str(args.script),
            "--step3-dir",
            str(step3_dir),
            "--output-dir",
            str(step4_dir),
            "--tau",
            str(args.tau),
        ]
        try:
            subprocess.run(command, cwd=project_root, check=True)
        except subprocess.CalledProcessError as exc:
            failed.append(video_stem)
            print(f"WARNING: [{index}/{total}] {video_stem} failed with exit code {exc.returncode}; continue")
            continue

        print(f"[{index}/{total}] {video_stem} done")

    merged = collect_results(args.input_root, video_names, args.step4_name)
    output_path = args.input_root / f"all_results_{args.step4_name}.json"
    output_path.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")

    print()
    print(f"Saved merged results to: {output_path}")
    print(f"Videos: {total}, failed: {len(failed)}")
    if failed:
        print("Failed videos:")
        for video_stem in failed:
            print(f"  {video_stem}")


def read_video_list(path: Path) -> list[str]:
    names = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not names:
        raise SystemExit(f"No videos found in {path}")
    return names


def resolve_path(path: Path, project_root: Path) -> Path:
    return path if path.is_absolute() else project_root / path


def collect_results(input_root: Path, video_names: list[str], step4_name: str) -> dict[str, list[dict]]:
    merged: dict[str, list[dict]] = {}
    for video_name in video_names:
        video_stem = Path(video_name).stem
        result_path = input_root / video_stem / step4_name / "results.json"
        if not result_path.exists():
            continue
        results = json.loads(result_path.read_text(encoding="utf-8"))
        merged[video_stem] = [
            {
                "category": item["category"],
                "confidence": item["confidence"],
                "start_seconds": item.get("start_seconds"),
                "end_seconds": item.get("end_seconds"),
            }
            for item in results
        ]
    return merged


if __name__ == "__main__":
    main()

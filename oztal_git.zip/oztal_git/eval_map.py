from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


DEFAULT_ANNOTATION_DIR = Path(
    r"D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_Temporal_annotations_test\annotation"
)
TIOU_THRESHOLDS = [0.3, 0.4, 0.5, 0.6, 0.7]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate temporal action detection mAP from all_results.json.")
    parser.add_argument("--predictions", type=Path, default=Path("output/batch_exp001/all_results.json"))
    parser.add_argument("--annotation-dir", type=Path, default=DEFAULT_ANNOTATION_DIR)
    parser.add_argument(
        "--classes",
        type=Path,
        default=Path("examples/thumos14_classes.txt"),
        help="Class list file. If omitted classes are inferred from prediction categories.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    predictions = load_predictions(args.predictions)
    classes = load_classes(args.classes, predictions)
    ground_truth = load_ground_truth(args.annotation_dir, classes)
    predictions_by_class = group_predictions_by_class(predictions, classes)

    mean_aps: list[float] = []
    ap_by_threshold: dict[float, dict[str, float]] = {}

    for tiou in TIOU_THRESHOLDS:
        per_class_ap = {
            class_name: compute_ap(predictions_by_class.get(class_name, []), ground_truth.get(class_name, {}), tiou)
            for class_name in classes
        }
        ap_by_threshold[tiou] = per_class_ap
        mean_ap = float(np.mean(list(per_class_ap.values()))) if per_class_ap else 0.0
        mean_aps.append(mean_ap)
        print(f"tIoU={tiou:.1f}  mAP={mean_ap * 100:.2f}%")

    avg_map = float(np.mean(mean_aps)) if mean_aps else 0.0
    print(f"Avg mAP = {avg_map * 100:.2f}%")

    print()
    print("AP at tIoU=0.5:")
    for class_name in classes:
        ap = ap_by_threshold[0.5].get(class_name, 0.0)
        print(f"{class_name}: {ap * 100:.2f}%")


def load_predictions(path: Path) -> dict[str, list[dict]]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_classes(path: Path, predictions: dict[str, list[dict]]) -> list[str]:
    if path and path.exists():
        return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]

    classes = sorted(
        {
            item["category"]
            for video_predictions in predictions.values()
            for item in video_predictions
            if "category" in item
        }
    )
    if not classes:
        raise SystemExit("No classes found. Provide --classes or non-empty predictions.")
    return classes


def load_ground_truth(annotation_dir: Path, classes: list[str]) -> dict[str, dict[str, list[tuple[float, float]]]]:
    ground_truth: dict[str, dict[str, list[tuple[float, float]]]] = {}
    for class_name in classes:
        path = annotation_dir / f"{class_name}_test.txt"
        class_gt: dict[str, list[tuple[float, float]]] = {}
        if not path.exists():
            print(f"WARNING: annotation file not found: {path}")
            ground_truth[class_name] = class_gt
            continue

        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 3:
                print(f"WARNING: invalid annotation line {path}:{line_number}: {line}")
                continue
            video_id = Path(parts[0]).stem
            start = float(parts[1])
            end = float(parts[2])
            class_gt.setdefault(video_id, []).append((start, end))
        ground_truth[class_name] = class_gt
    return ground_truth


def group_predictions_by_class(
    predictions: dict[str, list[dict]],
    classes: list[str],
) -> dict[str, list[dict]]:
    class_set = set(classes)
    grouped: dict[str, list[dict]] = {class_name: [] for class_name in classes}
    for video_id, video_predictions in predictions.items():
        video_stem = Path(video_id).stem
        for item in video_predictions:
            category = item.get("category")
            if category not in class_set:
                continue
            if item.get("start_seconds") is None or item.get("end_seconds") is None:
                continue
            grouped[category].append(
                {
                    "video_id": video_stem,
                    "start": float(item["start_seconds"]),
                    "end": float(item["end_seconds"]),
                    "confidence": float(item.get("confidence", 0.0)),
                }
            )
    return grouped


def compute_ap(
    predictions: list[dict],
    ground_truth: dict[str, list[tuple[float, float]]],
    tiou_threshold: float,
) -> float:
    num_gt = sum(len(items) for items in ground_truth.values())
    if num_gt == 0:
        return 0.0
    if not predictions:
        return 0.0

    sorted_predictions = sorted(predictions, key=lambda item: item["confidence"], reverse=True)
    matched = {video_id: np.zeros(len(items), dtype=bool) for video_id, items in ground_truth.items()}
    tp = np.zeros(len(sorted_predictions), dtype=np.float64)
    fp = np.zeros(len(sorted_predictions), dtype=np.float64)

    for index, prediction in enumerate(sorted_predictions):
        video_id = prediction["video_id"]
        gt_segments = ground_truth.get(video_id, [])
        if not gt_segments:
            fp[index] = 1.0
            continue

        tiou_values = np.array(
            [temporal_iou((prediction["start"], prediction["end"]), segment) for segment in gt_segments],
            dtype=np.float64,
        )
        matched_gt = False
        for gt_index in tiou_values.argsort()[::-1]:
            if tiou_values[gt_index] < tiou_threshold:
                break
            if matched[video_id][gt_index]:
                continue
            tp[index] = 1.0
            matched[video_id][gt_index] = True
            matched_gt = True
            break

        if not matched_gt:
            fp[index] = 1.0

    tp_cumsum = np.cumsum(tp)
    fp_cumsum = np.cumsum(fp)
    recall = tp_cumsum / num_gt
    precision = tp_cumsum / np.maximum(tp_cumsum + fp_cumsum, np.finfo(np.float64).eps)
    return interpolated_ap(recall, precision)


def temporal_iou(a: tuple[float, float], b: tuple[float, float]) -> float:
    intersection = max(0.0, min(a[1], b[1]) - max(a[0], b[0]))
    union = max(a[1], b[1]) - min(a[0], b[0])
    if union <= 0:
        return 0.0
    return intersection / union


def interpolated_ap(recall: np.ndarray, precision: np.ndarray) -> float:
    mrec = np.concatenate(([0.0], recall, [1.0]))
    mpre = np.concatenate(([0.0], precision, [0.0]))

    for index in range(mpre.size - 1, 0, -1):
        mpre[index - 1] = max(mpre[index - 1], mpre[index])

    change_indices = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[change_indices + 1] - mrec[change_indices]) * mpre[change_indices + 1]))


if __name__ == "__main__":
    main()

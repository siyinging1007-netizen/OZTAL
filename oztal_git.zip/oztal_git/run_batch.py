﻿from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


DEFAULT_VIDEO_DIR = Path(r"D:\ZYY\VIDEO LEARNING\dataset\THUMOS14-ALL\test data\TH14_test_set_mp4")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run run_pipeline.py for a list of THUMOS14 test videos and merge all predictions."
    )
    parser.add_argument("--video-list", type=Path, default=Path("video_list.txt"), help="Text file with one video filename per line.")
    parser.add_argument("--video-dir", type=Path, default=DEFAULT_VIDEO_DIR, help="Directory containing test videos.")
    parser.add_argument("--classes", type=Path, default=Path("examples/classes.txt"), help="Class list passed to run_pipeline.py.")
    parser.add_argument("--output-root", type=Path, default=Path("output/batch_exp001"), help="Batch output root.")
    parser.add_argument("--device", default="cuda", help="Device passed to run_pipeline.py.")
    parser.add_argument("--python", default=sys.executable, help="Python executable used to run run_pipeline.py.")
    parser.add_argument("--pipeline", type=Path, default=Path("run_pipeline.py"), help="Pipeline script path.")

    parser.add_argument("--num-frames", type=int, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--resize", type=int, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--video-batch-size", type=int, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--viclip-repo", type=Path, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--checkpoint", type=Path, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--viclip-adapter", help="Forwarded to run_pipeline.py.")
    parser.add_argument("--prompt-mode", choices=("deepseek_sentence",), help="Forwarded to run_pipeline.py.")
    parser.add_argument("--deepseek-model", help="Forwarded to run_pipeline.py.")
    parser.add_argument(
        "--reuse-feature-root",
        type=Path,
        help="Existing batch output root. For each video, reuse <root>/<video>/step1_feature_extraction/video_features.npy.",
    )
    parser.add_argument("--memory-size", type=int, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--theta", type=float, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--scale", type=float, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--tau", type=float, help="Forwarded to run_pipeline.py.")
    parser.add_argument("--quiet", action="store_true", help="Suppress per-video pipeline stdout/stderr unless a video fails.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parent
    video_names = read_video_list(resolve_path(args.video_list, project_root))
    total = len(video_names)
    failed: list[str] = []
    text_feature_dir = find_text_feature_dir(args.output_root)

    for index, video_name in enumerate(video_names, start=1):
        video_stem = Path(video_name).stem
        video_path = args.video_dir / video_name
        video_output_dir = args.output_root / video_stem
        result_path = video_output_dir / "step4_span_prediction" / "results.json"

        if result_path.exists():
            print(f"[{index}/{total}] {video_stem} skipped")
            continue

        command = build_pipeline_command(args, video_path, video_output_dir, text_feature_dir)
        try:
            if args.quiet:
                completed = subprocess.run(command, cwd=project_root, capture_output=True, text=True)
                if completed.returncode != 0:
                    print(completed.stdout, end="")
                    print(completed.stderr, end="")
                    raise subprocess.CalledProcessError(completed.returncode, command)
            else:
                subprocess.run(command, cwd=project_root, check=True)
        except subprocess.CalledProcessError as exc:
            failed.append(video_stem)
            print(f"WARNING: [{index}/{total}] {video_stem} failed with exit code {exc.returncode}; continue")
            continue

        if text_feature_dir is None:
            candidate = video_output_dir / "step1_feature_extraction"
            if has_text_features(candidate):
                text_feature_dir = candidate
                print(f"Reusing text features from: {text_feature_dir}")

        print(f"[{index}/{total}] {video_stem} done")

    all_results = collect_results(args.output_root, video_names)
    output_path = args.output_root / "all_results.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(all_results, ensure_ascii=False, indent=2), encoding="utf-8")

    print()
    print(f"Saved merged results to: {output_path}")
    print(f"Videos: {total}, succeeded or skipped: {total - len(failed)}, failed: {len(failed)}")
    if failed:
        print("Failed videos:")
        for video_stem in failed:
            print(f"  {video_stem}")


def read_video_list(path: Path) -> list[str]:
    names = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not names:
        raise SystemExit(f"No videos found in {path}")
    return names


def resolve_path(path: Path, project_root: Path) -> Path:
    return path if path.is_absolute() else project_root / path


def build_pipeline_command(
    args: argparse.Namespace,
    video_path: Path,
    output_root: Path,
    text_feature_dir: Path | None,
) -> list[str]:
    command = [
        args.python,
        str(args.pipeline),
        "--video",
        str(video_path),
        "--classes",
        str(args.classes),
        "--output-root",
        str(output_root),
        "--device",
        args.device,
    ]
    append_optional(command, "--num-frames", args.num_frames)
    append_optional(command, "--resize", args.resize)
    append_optional(command, "--video-batch-size", args.video_batch_size)
    append_optional(command, "--viclip-repo", args.viclip_repo)
    append_optional(command, "--checkpoint", args.checkpoint)
    append_optional(command, "--viclip-adapter", args.viclip_adapter)
    append_optional(command, "--prompt-mode", args.prompt_mode)
    append_optional(command, "--deepseek-model", args.deepseek_model)
    if args.reuse_feature_root is not None:
        append_optional(command, "--reuse-video-features", resolve_reuse_video_features(args.reuse_feature_root, video_path.stem))
    append_optional(command, "--reuse-text-features", text_feature_dir)
    append_optional(command, "--memory-size", args.memory_size)
    append_optional(command, "--theta", args.theta)
    append_optional(command, "--scale", args.scale)
    append_optional(command, "--tau", args.tau)
    return command


def resolve_reuse_video_features(root: Path, video_stem: str) -> Path:
    step1_dir = root / video_stem / "step1_feature_extraction"
    direct_file = root / video_stem / "video_features.npy"
    if (step1_dir / "video_features.npy").exists():
        return step1_dir
    if direct_file.exists():
        return direct_file
    return step1_dir


def find_text_feature_dir(output_root: Path) -> Path | None:
    if not output_root.exists():
        return None
    for step1_dir in sorted(output_root.glob("*/step1_feature_extraction")):
        if has_text_features(step1_dir):
            return step1_dir
    return None


def has_text_features(step1_dir: Path) -> bool:
    return all(
        (step1_dir / filename).exists()
        for filename in (
            "prompt_text_features.npy",
            "text_features.npy",
            "foreground_feature.npy",
            "background_feature.npy",
        )
    )


def append_optional(command: list[str], flag: str, value: object | None) -> None:
    if value is not None:
        command.extend([flag, str(value)])


def collect_results(output_root: Path, video_names: list[str]) -> dict[str, list[dict]]:
    merged: dict[str, list[dict]] = {}
    for video_name in video_names:
        video_stem = Path(video_name).stem
        result_path = output_root / video_stem / "step4_span_prediction" / "results.json"
        if not result_path.exists():
            continue
        results = json.loads(result_path.read_text(encoding="utf-8"))
        merged[video_stem] = [
            {
                "category": item["category"],
                "confidence": item["confidence"],
                "start_seconds": item.get("start_seconds"),
                "end_seconds": item.get("end_seconds"),
            }
            for item in results
        ]
    return merged


if __name__ == "__main__":
    main()


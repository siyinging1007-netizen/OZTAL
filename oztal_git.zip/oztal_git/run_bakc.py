from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from src.bakc import compute_bakc
from src.paths import STEP1_DIR, STEP2_DIR, STEP3_DIR, ensure_dir


OUTPUT_DIR = ensure_dir(STEP3_DIR)
PREV_DIR = STEP2_DIR
STEP1_FEATURE_DIR = STEP1_DIR
SCALE = 100.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run OZ-TAL step 3: Background-Aware K-way Classification."
    )
    parser.add_argument("--step1-dir", type=Path, default=STEP1_DIR, help="Directory containing step 1 text/background features.")
    parser.add_argument("--step2-dir", type=Path, default=STEP2_DIR, help="Directory containing step 2 enhanced video features.")
    parser.add_argument("--output-dir", type=Path, default=STEP3_DIR, help="Directory used to save BAKC outputs.")
    parser.add_argument("--scale", type=float, default=SCALE, help="Temperature scale for matching logits.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = ensure_dir(args.output_dir)
    z = torch.from_numpy(np.load(args.step2_dir / "enhanced_video_features.npy")).float()
    f_cls = torch.from_numpy(np.load(args.step1_dir / "text_features.npy")).float()
    f_b = torch.from_numpy(np.load(args.step1_dir / "background_feature.npy")).float()
    metadata = json.loads((args.step1_dir / "metadata.json").read_text(encoding="utf-8"))
    classes = metadata["classes"]

    k, r, alpha, y = compute_bakc(z, f_cls, f_b, scale=args.scale)
    save_outputs(k, r, alpha, y, classes, output_dir, args.scale, metadata.get("windows"))
    print_summary(k, r, y, classes, metadata.get("windows"))
    plot_scores(k, y, classes, output_dir / "scores.png")


def save_outputs(
    k: torch.Tensor,
    r: torch.Tensor,
    alpha: torch.Tensor,
    y: torch.Tensor,
    classes: list[str],
    output_dir: Path,
    scale: float,
    windows: list[dict] | None = None,
) -> None:
    np.save(output_dir / "k_logits.npy", k.cpu().numpy().astype(np.float32))
    np.save(output_dir / "r_background.npy", r.cpu().numpy().astype(np.float32))
    np.save(output_dir / "alpha.npy", alpha.cpu().numpy().astype(np.float32))
    np.save(output_dir / "y_scores.npy", y.cpu().numpy().astype(np.float32))
    (output_dir / "classes.json").write_text(
        json.dumps(classes, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    metadata = {
        "scale": scale,
        "feature_shapes": {
            "k": list(k.shape),
            "r": list(r.shape),
            "alpha": list(alpha.shape),
            "y": list(y.shape),
        },
        "classes": classes,
        "windows": windows,
    }
    (output_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def print_summary(
    k: torch.Tensor,
    r: torch.Tensor,
    y: torch.Tensor,
    classes: list[str],
    windows: list[dict] | None = None,
) -> None:
    k_np = k.cpu().numpy()
    r_np = r.cpu().numpy()
    y_np = y.cpu().numpy()
    print("OZ-TAL step 3: Background-Aware K-way Classification")
    print(f"k logits: {list(k_np.shape)}  # [time_windows, classes]")
    print(f"r background: {list(r_np.shape)}")
    print(f"y scores: {list(y_np.shape)}")
    print(f"r_t mean={r_np.mean():.4f}, std={r_np.std():.4f}, min={r_np.min():.4f}, max={r_np.max():.4f}")
    print()
    counts = Counter()
    for frame_index, row in enumerate(y_np):
        class_index = int(row.argmax())
        counts[classes[class_index]] += 1
        if windows and frame_index < len(windows):
            time_label = f"{windows[frame_index]['start_seconds']:.2f}s->{windows[frame_index]['end_seconds']:.2f}s"
        else:
            time_label = f"window {frame_index:03d}"
        print(
            f"{time_label}: "
            f"{classes[class_index]} "
            f"k={k_np[frame_index, class_index]:.4f} "
            f"y={row[class_index]:.4f} "
            f"r={r_np[frame_index]:.4f}"
        )
    print()
    print("Top-class frame counts after BAKC:")
    for name, count in counts.items():
        print(f"{name}: {count}")


def plot_scores(k: torch.Tensor, y: torch.Tensor, classes: list[str], output_path) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib is not installed; skipped scores.png")
        return

    k_np = k.cpu().numpy()
    y_np = y.cpu().numpy()
    frames = np.arange(y_np.shape[0])
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
    for class_index, class_name in enumerate(classes):
        axes[0].plot(frames, k_np[:, class_index], label=class_name)
        axes[1].plot(frames, y_np[:, class_index], label=class_name)
    axes[0].set_title("Before BAKC penalty: k")
    axes[1].set_title("After BAKC penalty: y")
    axes[1].set_xlabel("Time-window index")
    for axis in axes:
        axis.set_ylabel("Score")
        axis.grid(True, alpha=0.3)
    axes[0].legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    main()

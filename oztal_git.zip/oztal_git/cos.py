import torch
import torch.nn.functional as F
from dotenv import load_dotenv

from extract_viclip_features import env_or_default, env_path
from src.backends import RealViCLIPBackend

load_dotenv("config.env")

pairs = [
    (
        "A scene depicting a player engaging in some sports activities",
        "A scene without sports activities",
    ),
    (
        "A person actively playing a sport, such as running, jumping, or playing ball on a field",
        "A quiet everyday scene with furniture, buildings, roads, or nature, and no people",
    ),
    (
        "An athlete performing a physical sport action on a court or field",
        "An empty indoor room, street, landscape, or building scene",
    ),
]

backend = RealViCLIPBackend(
    repo_path=env_path("OZTAL_VICLIP_REPO") or env_path("OZTAL_CHECKPOINT"),
    checkpoint_path=env_path("OZTAL_CHECKPOINT"),
    device=env_or_default("OZTAL_DEVICE", "cuda"),
    adapter_module=env_or_default("OZTAL_VICLIP_ADAPTER", None),
)

for fg, bg in pairs:
    features = backend.encode_text_prompts([fg, bg])
    fa = torch.from_numpy(features[0]).float().unsqueeze(0)
    fb = torch.from_numpy(features[1]).float().unsqueeze(0)
    cos = F.cosine_similarity(fa, fb, dim=-1)
    print(f"{cos.item():.4f} | fg={fg} | bg={bg}")

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Match extracted ViCLIP video/text features and compute class scores."
    )
    parser.add_argument(
        "--feature-dir",
        type=Path,
        required=True,
        help="Directory containing metadata.json, video_features.npy, and text_features.npy.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    feature_dir = args.feature_dir

    metadata = json.loads((feature_dir / "metadata.json").read_text(encoding="utf-8"))
    video_features = np.load(feature_dir / "video_features.npy")
    text_features = np.load(feature_dir / "text_features.npy")
    prompt_text_path = feature_dir / "prompt_text_features.npy"
    if prompt_text_path.exists():
        prompt_text_features = np.load(prompt_text_path)
        prompt_similarities = video_features @ prompt_text_features.T
        text_features_shape = list(prompt_text_features.shape)
    else:
        prompt_similarities = video_features @ text_features.T
        text_features_shape = list(text_features.shape)
    class_similarities = video_features @ text_features.T

    np.save(feature_dir / "prompt_similarities.npy", prompt_similarities)
    np.save(feature_dir / "class_similarities.npy", class_similarities)

    metadata.setdefault("feature_shapes", {})
    metadata["feature_shapes"]["prompt_similarities"] = list(prompt_similarities.shape)
    metadata["feature_shapes"]["class_similarities"] = list(class_similarities.shape)
    (feature_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("ViCLIP feature matching")
    print(f"feature_dir: {feature_dir}")
    print(f"video_features: {list(video_features.shape)}")
    print(f"text_features: {text_features_shape}")
    print(f"prompt similarities S_prompt=V@T.T: {list(prompt_similarities.shape)}")
    print(f"class similarities S_class: {list(class_similarities.shape)}")
    print()
    print("Top class per temporal window:")
    classes = metadata["classes"]
    for window_index, row in enumerate(class_similarities):
        class_index = int(row.argmax())
        print(
            f"window {window_index:02d}: "
            f"{classes[class_index]} "
            f"score={row[class_index]:.4f}"
        )


if __name__ == "__main__":
    main()
